"""Persian names for the operations the activity log records.

«رویداد های سامانه باید فارسی باشند چون سایت و پنل فارسی است.» — the panel is
Persian, so what it shows a reader must be Persian too.

**The stored value does not change.** `ActivityLog.operation` keeps its
`noun.verb` ASCII form, because it is a machine contract: the log is filtered by
it, the API exposes it, and rows already written carry it. Translating at write
time would have made every historical row unsearchable by the name the new rows
use, and would have put display text inside an audit record — the one table that
should be hardest to rewrite.

So this maps the stored value to what a reader sees, and nothing else. An
operation with no entry here falls back to its stored form: a missing
translation shows an ugly label, never a blank one, and never hides that the
event happened.
"""

#: Stored operation -> what the panel shows. Grouped by the object the
#: operation acts on, in the order the operations appear in the product.
OPERATION_LABELS = {
    # --- مشتریان -----------------------------------------------------------
    "customer.created": "ثبت مشتری",
    "customer.updated": "ویرایش مشتری",
    "customer.reactivated": "فعال‌سازی مجدد مشتری",
    "customer_phone.created": "افزودن شماره تماس",
    "customer_phone.updated": "ویرایش شماره تماس",
    "customer_phone.deactivated": "غیرفعال‌سازی شماره تماس",
    "customer_ledger.appended": "ثبت حرکت در دفتر حساب",
    # --- سرنخ و جامعه هدف ---------------------------------------------------
    "lead.created": "ثبت سرنخ",
    "lead.updated": "ویرایش سرنخ",
    "lead.reassigned": "واگذاری سرنخ",
    "target_audience.added": "افزودن به جامعه هدف",
    "target_audience.updated": "ویرایش جامعه هدف",
    "target_audience.status_derived": "به‌روزرسانی خودکار وضعیت جامعه هدف",
    # --- کالا و انبار -------------------------------------------------------
    "product.created": "ثبت کالا",
    "product.updated": "ویرایش کالا",
    "product.deactivated": "غیرفعال‌سازی کالا",
    "product.reactivated": "فعال‌سازی مجدد کالا",
    "product_category.created": "ثبت دسته‌بندی کالا",
    "product_category.updated": "ویرایش دسته‌بندی کالا",
    "product_category.deactivated": "غیرفعال‌سازی دسته‌بندی کالا",
    "product_category.reactivated": "فعال‌سازی مجدد دسته‌بندی کالا",
    "warehouse.created": "ثبت انبار",
    "warehouse.updated": "ویرایش انبار",
    "warehouse.deactivated": "غیرفعال‌سازی انبار",
    "warehouse.reactivated": "فعال‌سازی مجدد انبار",
    "stock_movement.recorded": "ثبت حرکت موجودی",
    # --- اسناد فروش ---------------------------------------------------------
    "quotation.created": "ثبت پیش‌فاکتور",
    "quotation.updated": "ویرایش پیش‌فاکتور",
    "quotation.items_replaced": "تغییر اقلام پیش‌فاکتور",
    "quotation.status_changed": "تغییر وضعیت پیش‌فاکتور",
    "order.created": "ثبت درخواست تأمین",
    "order.updated": "ویرایش درخواست تأمین",
    "order.items_replaced": "تغییر اقلام درخواست تأمین",
    "order.status_changed": "تغییر وضعیت درخواست تأمین",
    "order.cancelled_for_shortage": "لغو درخواست تأمین به دلیل کمبود موجودی",
    "order.created_from_invoice": "ثبت درخواست تأمین از فاکتور",
    # --- مشتریان و کمپین‌ها (۲.۳۵.۰ تا ۲.۳۶.۰) ---------------------------------
    "customer_category.created": "ساخت دسته‌بندی مشتری",
    "customer_category.renamed": "تغییر نام دسته‌بندی مشتری",
    "customer_category.deactivated": "غیرفعال‌سازی دسته‌بندی مشتری",
    "customer_category.reactivated": "فعال‌سازی دسته‌بندی مشتری",
    "customer_category.transferred": "انتقال مشتریان یک دسته‌بندی",
    "campaign.created": "ساخت کمپین",
    "campaign.updated": "ویرایش کمپین",
    "campaign.status_changed": "تغییر وضعیت کمپین",
    "campaign_member.added": "افزودن مخاطب به کمپین",
    "campaign_member.assigned": "واگذاری مخاطب کمپین",
    "campaign_member.stage_changed": "تغییر مرحلهٔ مخاطب کمپین",
    "invoice.campaign_attributed": "تغییر کمپین فاکتور",
    "sale.created": "ثبت فروش",
    "sale.cancelled": "ابطال فروش",
    # --- فاکتور -------------------------------------------------------------
    "invoice.created": "ثبت فاکتور",
    "invoice.updated": "ویرایش فاکتور",
    "invoice.items_replaced": "تغییر اقلام فاکتور",
    "invoice.issued": "صدور فاکتور",
    "invoice.cancelled": "ابطال فاکتور",
    "invoice.reissued": "ابطال و صدور مجدد فاکتور",
    "invoice.order_linked": "پیوند فاکتور به درخواست تأمین",
    "invoice.manual_paid_entry": "ثبت دستی مبلغ پرداختی",
    "invoice.installments_changed": "تغییر اقساط فاکتور",
    "postal_shipment.created": "ثبت مرسوله پستی",
    # --- دریافت و پرداخت ----------------------------------------------------
    "payment.registered": "ثبت سند مالی",
    "payment.allocated": "تخصیص دریافت به فاکتور",
    "payment.allocation_released": "آزادسازی تخصیص",
    "payment.cancelled": "ابطال سند مالی",
    "payment.corrected": "اصلاح سند مالی",
    "cheque.status_changed": "تغییر وضعیت چک",
    "cheque.registration_changed": "تغییر حالت ثبت چک",
    "installment_plan.created": "ثبت طرح اقساط",
    "installment_plan.cancelled": "لغو طرح اقساط",
    # --- خدمات پس از فروش ---------------------------------------------------
    "after_sales.created": "ثبت درخواست پس از فروش",
    "after_sales.assigned": "واگذاری درخواست پس از فروش",
    "after_sales.status_changed": "تغییر وضعیت درخواست پس از فروش",
    "after_sales.closed": "بستن درخواست پس از فروش",
    "after_sales.appointment_scheduled": "زمان‌بندی قرار پس از فروش",
    # --- مدارک و پیامک ------------------------------------------------------
    "sales_document.registered": "ثبت مدرک فروش",
    "sales_document.postal_status_changed": "تغییر وضعیت پستی مدرک",
    "sales_document.deactivated": "غیرفعال‌سازی مدرک فروش",
    "inbound_sms.stored": "دریافت پیامک",
    "outbound_sms.sent": "ارسال پیامک",
    "outbound_sms.failed": "ارسال ناموفق پیامک",
    "sms_template.created": "ساخت الگوی پیامک",
    "sms_template.deleted": "حذف الگوی پیامک",
    "sms_campaign.created": "ساخت کمپین پیامکی",
    "sms_campaign.cancelled": "لغو کمپین پیامکی",
    "sms_provider_settings.updated": "تغییر تنظیمات سامانهٔ پیامک",
    "post_provider_settings.updated": "تغییر تنظیمات سامانهٔ پست",
    "attachment.uploaded": "افزودن پیوست",
    "attachment.deleted": "حذف پیوست",
    "brand_settings.updated": "تغییر برند پنل",
    "dashboard_settings.updated": "تغییر چیدمان داشبورد",
    # پشتیبان‌گیری (common/backups.py). هر سه رویداد عمداً ثبت
    # می‌شوند: دانلود یک نسخه یعنی کل پایگاه داده از سرور خارج شده،
    # و بازگردانی تنها عملیاتی است که تاریخچهٔ فقط-افزودنی را بازنویسی
    # می‌کند — دقیقاً همان دو چیزی که بعداً کسی دنبالشان می‌گردد.
    "backup.create": "درخواست پشتیبان‌گیری",
    "backup.downloaded": "دانلود پشتیبان",
    "backup.restore": "درخواست بازگردانی پایگاه داده",
    "chat_thread.started": "شروع گفت‌وگو",
    "chat_message.sent": "ارسال پیام گفت‌وگو",
    # --- کاربران ------------------------------------------------------------
    "user.created": "ثبت کاربر",
    "user.updated": "ویرایش کاربر",
    "user.profile_updated": "ویرایش پروفایل",
    "user.role_changed": "تغییر نقش کاربر",
    "user.permissions_overridden": "تغییر مجوزهای اختصاصی کاربر",
    "user.permissions_reset": "بازنشانی مجوزهای کاربر به پیش‌فرض نقش",
    "user.sessions_revoked": "ابطال نشست‌های کاربر",
    "user.platform_admin_bootstrapped": "ایجاد مدیر پلتفرم",
    "user.uat_seeded": "ایجاد داده آزمایشی",
    # --- پروفایل: یادداشت، وظیفه، امتیاز (۲.۲۰.۰) ------------------------------
    "person_note.created": "ثبت یادداشت پروفایل",
    "person_note.updated": "ویرایش یادداشت پروفایل",
    "person_note.deleted": "حذف یادداشت پروفایل",
    "task.created": "ثبت وظیفه",
    "task.updated": "ویرایش وظیفه",
    "task.completed": "انجام وظیفه",
    "task.cancelled": "لغو وظیفه",
    "task.reopened": "بازکردن دوبارهٔ وظیفه",
    "task.deleted": "حذف وظیفه",
    "scoring.weights_updated": "تغییر وزن‌های امتیازدهی",
    # --- یکپارچه‌سازی (۲.۲۱.۰) -----------------------------------------------
    "integration.created": "افزودن اتصال یکپارچه‌سازی",
    "integration.updated": "ویرایش اتصال یکپارچه‌سازی",
    "integration.deleted": "حذف اتصال یکپارچه‌سازی",
    "integration.tested": "آزمایش اتصال یکپارچه‌سازی",
    "webhook_subscription.created": "افزودن وب‌هوک خروجی",
    "webhook_subscription.updated": "ویرایش وب‌هوک خروجی",
    "webhook_subscription.deleted": "حذف وب‌هوک خروجی",
    "api_token.created": "ساخت توکن API",
    "api_token.revoked": "باطل کردن توکن API",
    # --- تلفن (۲.۲۲.۰) -----------------------------------------------------
    "extension.saved": "ذخیرهٔ داخلی تلفن",
    "extension.deleted": "حذف داخلی تلفن",
    "call.recording_played": "پخش ضبط مکالمه",
    "call.originate_requested": "درخواست برقراری تماس",
    # --- عمومی --------------------------------------------------------------
    "cancel": "ابطال",
}


def operation_label(operation):
    """The Persian name for a stored operation, or the stored value itself.

    Falling back to the raw value is deliberate. A new operation added without a
    translation should look unfinished in the panel; it must never disappear
    from the audit trail, and it must never be shown as blank — an audit row a
    reader cannot name is worse than one named in English.
    """
    if not operation:
        return "—"
    return OPERATION_LABELS.get(operation, operation)
