# Gitignored, temporary, session-local settings module used only for live
# browser verification during development. Never shipped, never imported by
# any test. Set DJANGO_DEBUG=true in the environment before importing this so
# DEBUG-derived flags (CSRF/session cookie Secure) come out correctly.
from pathlib import Path

from config.settings import *  # noqa: F401,F403

# `preview_start` launches this via .claude/launch.json, which has no way to
# set DJANGO_DEBUG before config.settings is imported — so DEBUG (and every
# cookie flag config/settings.py derives from it at *that* module's own
# import time) must be overridden here explicitly, by name, not just relied
# on from the environment. Same cascade this codebase already hit once in
# scripts/preview_runner.py.
DEBUG = True
SESSION_COOKIE_SECURE = False
CSRF_COOKIE_SECURE = False

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": str(Path(BASE_DIR) / "devcheck.sqlite3"),
    }
}
PASSWORD_HASHERS = ["django.contrib.auth.hashers.MD5PasswordHasher"]
ENABLE_API_DOCS = True

# The panel must render every module during this visual audit, regardless of
# what a real customer's manifest would enable.
DEPLOYMENT_PROFILE_ENABLES_ALL_FEATURES = True
# A fixed, public key for the local demo only (2.21.0) — it protects nothing real.
DOLPHIN_SECRETS_KEY = "thfvINa4uBmXMreGTW2L4BP_AT8kkfySQKEdWDjUM00="
DOLPHIN_WEBHOOKS_ALLOW_PRIVATE_TARGETS = True

# Live updates (2.38.0), so the development server serves its own streams.
REALTIME_ENABLED = True
REALTIME_SERVE_STREAMS = True
