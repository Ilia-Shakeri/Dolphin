from datetime import datetime, time, timedelta

from django.db import transaction
from django.db.models import ProtectedError
from django.utils import timezone
from django.utils.dateparse import parse_date
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.exceptions import PermissionDenied, ValidationError
from rest_framework.response import Response

from accounts.access import can_delete
from auditlog.services import log_activity
from common.exceptions import BusinessConflictError, BusinessPermissionDenied
from common.permissions import FeatureGatedAPIMixin
from common.throttles import SensitiveRateThrottle


def start_of_day(day):
    """Midnight on `day` in the deployment's timezone.

    Built in local time on purpose: a person filtering "from 1405/05/01" means
    the day as it is lived in Tehran, not a UTC boundary that would cut it
    three and a half hours early.
    """
    return timezone.make_aware(datetime.combine(day, time.min))


def filter_by_date_window(queryset, query_params, *, field="created_at",
                          names=("created_from", "created_to")):
    """Narrow `queryset` to a day window given as two ISO dates.

    One implementation rather than one per viewset. The customers page has
    filtered by registration date since 1.x, and the system-events page was
    given the same control on 2026-09-20 («فیلتر زمانی باید وجود داشته
    باشد») — two pages asking the same question of two different columns, so
    the column is a parameter and the rule is not written twice.

    Two decisions are carried here rather than left to each caller:

    * the upper bound is exclusive of the *next* day rather than inclusive of
      a timestamp, so a row recorded at 23:59 on the closing day is still
      inside the window — which is what a person picking "to 1405/05/09"
      means;
    * a malformed date is a request error, not a silently ignored parameter.
      Quietly dropping it would show the wrong rows while looking like the
      filter worked.
    """
    from_name, to_name = names
    bounds = {from_name: query_params.get(from_name), to_name: query_params.get(to_name)}
    parsed = {}
    errors = {}
    for name, raw in bounds.items():
        if not raw:
            continue
        value = parse_date(raw)
        if value is None:
            errors[name] = ["تاریخ را به قالب YYYY-MM-DD وارد کنید."]
        else:
            parsed[name] = value
    if errors:
        raise ValidationError(errors)
    if from_name in parsed:
        queryset = queryset.filter(**{f"{field}__gte": start_of_day(parsed[from_name])})
    if to_name in parsed:
        queryset = queryset.filter(
            **{f"{field}__lt": start_of_day(parsed[to_name] + timedelta(days=1))}
        )
    return queryset


class StrictQueryParametersMixin(FeatureGatedAPIMixin):
    common_list_query_parameters = {"format", "ordering", "page", "search"}
    list_query_parameters = set()
    action_query_parameters = {}

    def initial(self, request, *args, **kwargs):
        super().initial(request, *args, **kwargs)
        if request.method not in {"GET", "HEAD"}:
            return
        action_name = getattr(self, "action", None)
        allowed = {"format"} | set(self.action_query_parameters.get(action_name, set()))
        if action_name == "list":
            allowed |= self.common_list_query_parameters | set(self.list_query_parameters)
        errors = {
            name: ["پارامتر نامعتبر است."]
            for name in sorted(set(request.query_params) - allowed)
        }
        for name in sorted(set(request.query_params) & allowed):
            if len(request.query_params.getlist(name)) > 1:
                errors[name] = ["این پارامتر باید فقط یک‌بار وارد شود."]
        if errors:
            raise ValidationError(errors)


class HardDeleteMixin:
    """Real, irreversible deletion of one row, or several — for correcting a
    mistaken entry, never a bulk clean-up tool.

    Who may delete: the Platform Admin, always; anyone else only when granted
    this viewset's `delete_capability` on their permission matrix
    (`accounts.access.can_delete`). Until 2.18.8 it was the Platform Admin
    alone, with no way to delegate (2026-09-02 decision); the product owner
    then asked for exactly that delegation — «مدیر اصلی پنل باید بتواند هر
    چیزی را که می‌خواهد حذف کند، ولی کاربران دیگر باید مجوز بگیرند». Enforced
    here, at the object boundary, regardless of what a viewset's own
    `permission_classes` would otherwise allow through for the HTTP method,
    and on top of the viewset's own object scope: `destroy` goes through
    `get_object` and `bulk_delete` through the list queryset, so a granted
    user can delete only the rows they can already see.

    Deletion is safe to hand over at all only because of a pre-existing
    schema property, not new code written for this: every foreign key in this
    project is `on_delete=PROTECT`, with the sole exception of
    `UserCapabilityOverride`'s cascade to its own `User` row (a personal
    setting, not a business record). A row anything else still points to
    therefore cannot be deleted out from under those references — Django
    raises `ProtectedError` before any row is touched, and that is turned
    into an ordinary Persian conflict response instead of an unhandled 500,
    pointing the admin at deactivation instead.

    Every deletion is written to the audit log *before* the row disappears —
    `ActivityLog.object_type`/`object_id` are plain strings captured at write
    time, not a live foreign key, so the record of who deleted what survives
    the row itself.
    """

    def get_throttles(self):
        # Composes with `SensitiveActionThrottleMixin.get_throttles` (whoever
        # is mixed in closer to `object` in the MRO runs first via `super()`)
        # rather than requiring every consuming viewset to remember to list
        # "destroy" and "bulk_delete" in its own `sensitive_actions` — this
        # throttle applies to every viewset that gets real DELETE from this
        # mixin, unconditionally, including one with no `sensitive_actions`
        # of its own (e.g. `InteractionViewSet`).
        throttles = super().get_throttles()
        if getattr(self, "action", None) in {"destroy", "bulk_delete"}:
            throttles.append(SensitiveRateThrottle())
        return throttles

    #: The `<module>.delete` capability that lets someone other than the
    #: Platform Admin delete through this viewset. `None` keeps it Platform-
    #: Admin-only — user administration, which no permission matrix governs.
    delete_capability = None

    #: `False` for financial documents (quotations, orders, invoices,
    #: payments, sales): nobody deletes them, the Platform Admin included —
    #: a wrong one is cancelled or reversed, which keeps the money trail
    #: (product owner, 2026-09-28). The database role has no DELETE on
    #: their tables either (`scripts/bootstrap-postgres.sh`).
    records_deletable = True
    NOT_DELETABLE_MESSAGE = "اسناد مالی حذف نمی‌شوند؛ برای اصلاح، سند را ابطال کنید یا سند برگشتی ثبت کنید."

    def _extra_delete_guard(self, request, instance):
        """Hook for a subclass to refuse one specific row beyond the blanket
        Platform-Admin-only gate — e.g. `UserViewSet` refusing self-deletion
        and refusing to ever remove the Platform Admin account through this
        path. A no-op here; raise `BusinessPermissionDenied` to refuse.
        """
        return

    def _require_delete_permission(self, request):
        if not self.records_deletable:
            raise BusinessPermissionDenied(self.NOT_DELETABLE_MESSAGE)
        if not can_delete(request.user, self.delete_capability):
            if self.delete_capability is None:
                raise BusinessPermissionDenied("حذف این رکورد فقط برای مدیر پلتفرم مجاز است.")
            raise BusinessPermissionDenied(
                "حذف این رکورد مجوز جداگانه می‌خواهد؛ مدیر پلتفرم می‌تواند آن را در مجوزهای شما فعال کند."
            )

    def _delete_instance(self, request, instance):
        self._extra_delete_guard(request, instance)
        with transaction.atomic():
            # Logged first: `instance.delete()` clears the in-memory `.pk`,
            # and the row itself is gone right after — this call is the only
            # remaining place either fact is recorded.
            log_activity(actor=request.user, operation=f"{instance._meta.model_name}.deleted", instance=instance)
            instance.delete()

    def destroy(self, request, *args, **kwargs):
        self._require_delete_permission(request)
        instance = self.get_object()
        try:
            self._delete_instance(request, instance)
        except ProtectedError as exc:
            raise BusinessConflictError(
                {"id": "این رکورد سوابق وابسته دارد و قابل حذف نیست؛ به‌جای حذف، غیرفعال‌سازی را در نظر بگیرید."}
            ) from exc
        return Response(status=status.HTTP_204_NO_CONTENT)

    #: A correction tool for a handful of mistaken rows, not a data-management
    #: bulk operation — capped well below anything a real cleanup job would need.
    MAX_BULK_DELETE = 200

    @action(detail=False, methods=["post"], url_path="bulk-delete")
    def bulk_delete(self, request):
        self._require_delete_permission(request)
        ids = request.data.get("ids")
        if (
            not isinstance(ids, list)
            or not (1 <= len(ids) <= self.MAX_BULK_DELETE)
            or not all(isinstance(pk, int) and not isinstance(pk, bool) for pk in ids)
        ):
            raise ValidationError({"ids": [f"فهرست شناسه‌های عددی (بین ۱ تا {self.MAX_BULK_DELETE} مورد) لازم است."]})
        # Scoped through the viewset's own `list` queryset — the same rows a
        # bulk-delete request could see are the same rows it can act on.
        found = {obj.pk: obj for obj in self.filter_queryset(self.get_queryset()).filter(pk__in=ids)}
        result = {"deleted": [], "protected": [], "denied": [], "not_found": []}
        for pk in ids:
            instance = found.get(pk)
            if instance is None:
                result["not_found"].append(pk)
                continue
            try:
                self._delete_instance(request, instance)
                result["deleted"].append(pk)
            except ProtectedError:
                result["protected"].append(pk)
            except PermissionDenied:
                # Catches `BusinessPermissionDenied` too (a subclass) — either
                # the blanket gate or a subclass's own `_extra_delete_guard`
                # (e.g. `UserViewSet` refusing self-deletion). One denied row
                # in a batch skips only that row.
                result["denied"].append(pk)
        return Response(result)


class AdminHardDeleteModelViewSet(HardDeleteMixin, StrictQueryParametersMixin, viewsets.ModelViewSet):
    """The ordinary CRUD viewset for this project: list/retrieve/create/update
    for whoever a viewset's own permission classes allow, plus real DELETE —
    single or bulk — for the Platform Admin and whoever holds the viewset's
    `delete_capability`, per `HardDeleteMixin` above.

    Formerly `NoDestroyModelViewSet`, when DELETE was refused to everyone;
    renamed with the 2026-09-02 change that gave Platform Admin real deletion,
    since the old name described exactly the opposite of what this now does.
    """

    # No bare PUT, same as before this class could destroy anything — a
    # write is always a partial PATCH in this project. "delete" is the one
    # method added by this change; `HardDeleteMixin.destroy` is what actually
    # gates who may use it.
    http_method_names = ["get", "post", "patch", "delete", "head", "options"]
