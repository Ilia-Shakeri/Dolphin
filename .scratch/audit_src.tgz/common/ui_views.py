from django.urls import reverse
from django.conf import settings
from django.contrib.auth import SESSION_KEY, logout
from django.http import HttpResponse
from django.shortcuts import redirect
from django.template.loader import render_to_string
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import ensure_csrf_cookie
from django.views.generic import TemplateView

from accounts.access import (
    assignable_roles,
    can_delete,
    capabilities_for,
    crm_identities,
    has_any_capability,
    is_crm_identity,
)
from accounts.avatars import default_avatar_url, has_avatar
from accounts.models import User
from attachments.selectors import PARENT_DELETE_CAPABILITY
from common import labels
from common.dashboard_layout import (
    arrange_capability_tiles,
    capability_tile_catalog,
    effective_layout,
    height_choices,
    layout_state,
    size_choices,
)
from common.integrations import any_integration_configurable, visible_integrations
from common.deployment.profile import active_profile, feature_enabled
from common.pdf import (
    PdfRendererBusy,
    PdfRendererUnavailable,
    inline_stylesheet,
    render_html_to_pdf,
    renderer_is_available,
)
from common.permissions import FeatureGatedViewMixin
from auditlog.selectors import activity_logs_for
from communications import sms
from aftersales.selectors import after_sales_requests_for
from billing.money import printed_line_breakdown
from billing.words import amount_in_words
from billing.selectors import (
    cheques_for,
    installment_plans_for,
    invoices_for,
    orders_for,
    payments_for,
)
from inventory.selectors import stock_items_for, stock_movements_for, warehouses_for
from sales.selectors import (
    customers_for,
    interactions_for,
    leads_for,
    product_categories_for,
    products_for,
    sales_documents_for,
    sales_for,
)


# Persian labels for backend-owned status vocabularies. The backend value stays
# the single source of truth; these are presentation only and a value with no
# entry falls back to the raw code rather than being hidden.
#: Re-exported, not redefined: these moved to `common/labels.py` when the
#: customer timeline needed the same words server-side, so the Python side
#: has one copy rather than two. Imported under their old names here because
#: this module's own readers (the printed invoice context below) use them.
DOCUMENT_STATUS_LABELS = labels.DOCUMENT_STATUS_LABELS
SETTLEMENT_LABELS = labels.SETTLEMENT_LABELS

#: How each dashboard tile is presented: an icon-font glyph from the theme's own set and
#: a UI-kit accent. Purely visual — the figure and its scope come from the
#: capability check above, never from this table.
DEFAULT_WIDGET_STYLE = {"icon": "di-element-11", "accent": "primary", "icon_paths": 4}
WIDGET_STYLE = {
    "customers": {"icon": "di-profile-user", "accent": "primary", "icon_paths": 4},
    "leads": {"icon": "di-phone", "accent": "info", "icon_paths": 2},
    "interactions": {"icon": "di-message-text-2", "accent": "info", "icon_paths": 3},
    "sales": {"icon": "di-handcart", "accent": "success", "icon_paths": 1},
    "sales_documents": {"icon": "di-delivery", "accent": "warning", "icon_paths": 5},
    "after_sales": {"icon": "di-shield-tick", "accent": "warning", "icon_paths": 2},
    # `dark` used to be the accent for both of these — on this panel's own
    # dark theme, `--bs-dark` sits a few shades off the card background
    # itself, so the icon badge read as barely-there against everything
    # around it. Product-owner request 2026-09-11 ("رنگی و جذاب"): every
    # tile earns a colour a reader can actually see.
    "users": {"icon": "di-people", "accent": "primary", "icon_paths": 5},
    "audit": {"icon": "di-shield-search", "accent": "danger", "icon_paths": 4},
}

ROLE_LABELS = {
    User.Role.SALES_AGENT: "بازاریاب (کال سنتر)",
    User.Role.SALES_MANAGER: "مدیر فروشگاه",
    User.Role.COMPANY_IT: "مدیر فنی مشتری",
    User.Role.PLATFORM_ADMIN: "مدیر پلتفرم",
}


@method_decorator(ensure_csrf_cookie, name="dispatch")
class DolphinLoginView(TemplateView):
    template_name = "common/login.html"

    def dispatch(self, request, *args, **kwargs):
        if is_crm_identity(request.user):
            return redirect("common_ui:home")
        if request.user.is_authenticated or SESSION_KEY in request.session:
            logout(request)
        return super().dispatch(request, *args, **kwargs)


@method_decorator(ensure_csrf_cookie, name="dispatch")
class ActiveCrmView(FeatureGatedViewMixin, TemplateView):
    def dispatch(self, request, *args, **kwargs):
        if not is_crm_identity(request.user):
            if request.user.is_authenticated or SESSION_KEY in request.session:
                logout(request)
            return redirect("common_ui:login")
        return super().dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        capabilities = capabilities_for(self.request.user)
        # Feature availability is a separate control from role permission: the
        # template hides a link when either says no, and the backend refuses
        # regardless of what the template rendered.
        context["features"] = active_profile().features
        context["capabilities"] = capabilities
        # The face the shell shows: this reader's own upload, or the UI kit
        # cartoon derived from their id. Resolved here rather than fetched by
        # the panel so the header never flashes a placeholder first.
        context["own_avatar_url"] = (
            f"/api/v1/users/{self.request.user.pk}/avatar/image/"
            if has_avatar(self.request.user)
            else (default_avatar_url(self.request.user) or "")
        )
        # PRELIMINARY, UNCOMMITTED — see integration/apps.py
        from common.deployment.profile import paired_accounting_base_url
        context["accounting_base_url"] = paired_accounting_base_url()
        # Live updates (2.38.0): the page declares its stream only where the
        # feature is on; a deployment without it renders nothing and the
        # panel behaves as before.
        from common import realtime

        context["realtime_url"] = reverse("realtime-events") if realtime.available() else ""
        context["role_label"] = ROLE_LABELS[self.request.user.role]
        if self.request.user.role == User.Role.SALES_AGENT and self.request.user.workstream == User.Workstream.AFTER_SALES:
            context["role_label"] = f'{context["role_label"]} — خدمات پس از فروش'
        context["can_manage_users"] = has_any_capability(
            self.request.user,
            "users.manage_agents",
            "users.manage_non_platform",
            "users.manage_all",
        )
        context["can_change_roles"] = has_any_capability(
            self.request.user,
            "users.manage_non_platform",
            "users.manage_all",
        )
        context["user_admin_label"] = (
            "مدیریت بازاریابان" if "users.manage_agents" in capabilities else "مدیریت کاربران"
        )
        # The incoming-call popup (telephony, 2.23.0): only for a reader with
        # an extension on a connection that shows popups.
        if feature_enabled("telephony"):
            from telephony.popup import popup_enabled

            context["call_popup"] = popup_enabled(self.request.user)
        context["can_deactivate_customers"] = self.request.user.role in {
            User.Role.SALES_MANAGER,
            User.Role.COMPANY_IT,
            User.Role.PLATFORM_ADMIN,
        }
        # Mirrors `sales.services.STATUS_ADMINISTRATORS`. Client-1 gives the
        # store manager the same functional access as the platform admin; what
        # stays Platform-Admin-only is the security plane — user accounts,
        # sessions, the deployment — not business workflow.
        status_admin = self.request.user.role in {
            User.Role.SALES_MANAGER, User.Role.PLATFORM_ADMIN
        }
        context["can_change_activation"] = status_admin
        # An order's status decides whether goods leave the warehouse, so it is
        # held by the same roles. Everything else on the order stays editable by
        # whoever may work it.
        context["can_change_order_status"] = status_admin
        # Mirrors exactly what `_require_target_audience_editor` allows, so the
        # page never offers a control the service would refuse, nor hides one it
        # would accept.
        context["can_edit_target_audience"] = self.request.user.role != User.Role.SALES_AGENT
        # Both customer books are open to every role; the import is its own
        # capability (`customers.import`).
        context["can_manage_customer_kinds"] = True
        context["can_assign_customer_owner"] = "customers.assign_owner" in capabilities
        context["can_manage_customer_categories"] = "customer_categories.manage" in capabilities
        context["can_import_customers"] = "customers.import" in capabilities
        context["can_reassign_leads"] = context["can_deactivate_customers"]
        context["can_manage_products"] = context["can_deactivate_customers"]
        context["can_cancel_sales"] = context["can_deactivate_customers"]
        context["can_manage_sales_documents"] = context["can_deactivate_customers"]
        context["can_manage_after_sales"] = "after_sales.manage" in capabilities
        context["can_view_company_reports"] = "reports.company" in capabilities
        context["can_manage_inventory"] = "inventory.manage" in capabilities
        context["can_read_inventory"] = bool(
            {"inventory.read", "inventory.manage"}.intersection(capabilities)
        )
        # Money capabilities. An agent prepares documents but never issues an
        # invoice, takes a payment, or reads the company ledger.
        context["can_manage_billing"] = bool(
            {"invoices.company", "orders.company"}.intersection(capabilities)
        )
        context["can_handle_payments"] = "payments.company" in capabilities
        context["can_view_ledger"] = bool(
            capabilities.intersection({"ledger.company", "ledger.own"})
        )
        context["can_view_sms_report"] = "sms.company" in capabilities
        # Same capability as the inbound report, and the same reasoning as
        # `send_outbound_sms` (communications/services.py): sending is a
        # manager-and-up capability for now, not yet opened to sales_agent.
        context["can_send_sms"] = "sms.company" in capabilities
        # Attachments: upload capability mirrors exactly the capability each
        # domain's own service layer already requires to write that parent
        # record (attachments/selectors.py's PARENT_WRITE_CAPABILITY) — shown
        # opportunistically per detail page; the API enforces it regardless.
        context["can_upload_attachment"] = {
            "customer": "customers.manage" in capabilities,
            "lead": "leads.manage" in capabilities,
            "invoice": "invoices.manage" in capabilities,
            "sales_document": "sales_documents.manage" in capabilities,
            "after_sales_request": bool({"after_sales.manage", "after_sales.work"}.intersection(capabilities)),
        }
        # Deletion follows the same rule as every other record since 2.18.8:
        # the Platform Admin always, anyone else only with the parent
        # module's own `<module>.delete` (`accounts.access.can_delete`,
        # re-checked by `attachments.services.delete_attachment`).
        context["can_delete_attachment"] = {
            field: can_delete(self.request.user, capability)
            for field, capability in PARENT_DELETE_CAPABILITY.items()
        }
        # The same pair `DolphinUserProfileView` and the user-performance report
        # itself require — an after-sales agent holds neither, so they get no
        # "عملکرد من" entry pointing at a page that would just refuse them.
        context["can_view_own_profile"] = bool(
            {"reports.own", "reports.company"}.intersection(capabilities)
        )
        context["can_view_audit"] = feature_enabled("audit_log") and bool(
            {"audit.non_platform", "audit.all"}.intersection(capabilities)
        )
        context["is_platform_navigation"] = "dashboard.platform" in capabilities
        # Real, irreversible row deletion — single or bulk, on every list
        # page. The Platform Admin always; since 2.18.8 anyone else too when
        # granted this page's own `delete_capability` on their permission
        # matrix (`accounts.access.can_delete`). A page that names none stays
        # Platform-Admin-only. The backend gate in
        # `common.viewsets.HardDeleteMixin` is what actually decides,
        # regardless of what this hides or shows.
        # Financial pages set `records_deletable = False` and never offer it.
        context["can_hard_delete"] = getattr(self, "records_deletable", True) and can_delete(
            self.request.user, getattr(self, "delete_capability", None)
        )
        # Mirrors DolphinBrandingSettingsView's own two gates exactly (feature
        # then role) — this only decides whether the link is offered; the
        # view enforces both again regardless of what this hid or showed.
        context["can_manage_branding"] = (
            feature_enabled("custom_branding") and self.request.user.role == User.Role.PLATFORM_ADMIN
        )
        # Mirrors DolphinSmsProviderSettingsView's own two gates exactly
        # (feature, then role) — same reasoning as can_manage_branding above.
        # Still used by the SMS-sending page's own contextual "تنظیم
        # سامانه" shortcut (sms/outbound.html) — a reader already on that
        # page wants SMS settings specifically, not the general hub below.
        context["can_manage_sms_provider"] = (
            feature_enabled("outbound_sms") and self.request.user.role == User.Role.PLATFORM_ADMIN
        )
        # The sidebar's and the settings page's own entry into «اتصال
        # سامانه‌ها» (product owner, 2026-09-21: «تنظیمات سامانهٔ پیامک
        # باید به اتصال سامانه‌ها تغییر اسم یابد») — true when this reader
        # may configure *any* registered integration, not only SMS, so a
        # Sales Manager who may set up the post connection but not the SMS
        # one still sees the entry. `any_integration_configurable` checks
        # each row's own feature and gate without the per-row status query
        # `visible_integrations` does, which this context builder — read on
        # every page — cannot afford.
        context["can_manage_integrations"] = any_integration_configurable(self.request.user)
        # Whether this reader may arrange their *own* dashboard — the
        # feature gate only, with no role test, because since 2.8.0 the
        # arrangement is per-user and personal. The deployment-wide layout
        # page an admin used to visit is gone; what replaced it is the
        # pencil control on the dashboard itself, and there is no role for
        # which "you may not choose the order of your own tiles" is a
        # sensible sentence. `DashboardLayoutView` re-checks the feature.
        context["can_arrange_dashboard"] = feature_enabled("dashboard_insights")
        return context


class DolphinHomeView(ActiveCrmView):
    template_name = "common/home.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        capabilities = context["capabilities"]
        role = self.request.user.role
        dashboard = {
            User.Role.PLATFORM_ADMIN: ("پنل مدیر پلتفرم", "مدیریت سامانه، کاربران، رویدادها و همه بخش‌های عملیاتی"),
            User.Role.SALES_MANAGER: ("پنل مدیر فروشگاه", "نمای سراسری کسب‌وکار، عملیات فروش و گزارش‌های این استقرار"),
            User.Role.SALES_AGENT: ("میز کار بازاریاب", "سرنخ‌های تخصیص‌یافته، تماس‌های دستی و عملکرد خود شما"),
            User.Role.COMPANY_IT: ("پنل مدیر فنی مشتری", "دسترسی عملیاتی شرکت و مشاهده رویدادهای غیرپلتفرمی"),
        }[role]
        if role == User.Role.SALES_AGENT and self.request.user.workstream == User.Workstream.AFTER_SALES:
            dashboard = (
                "میز کار خدمات پس از فروش",
                "پرونده‌های تخصیص‌یافته و اقدام‌های ثبت‌شده شما",
            )
        widgets = []
        # A dashboard tile links into a module, so it needs the feature as well
        # as the capability. Both controls are consulted, neither replaces the
        # other, and the target page enforces both again.
        widget_features = {
            "customers": "customers",
            "leads": "leads",
            "interactions": "leads",
            "sales": "sales",
            "sales_documents": "sales_documents",
            "after_sales": "after_sales",
        }

        # `count` is the scope's own `.count`, called only for a tile this
        # reader actually gets (2.18.9). Until then every one of the twelve
        # counts below ran on every dashboard load, whichever tiles the role
        # held — the `.count()` was evaluated as an argument before `add`
        # ever checked the capability.
        def add(capability, label, count, url_name):
            feature = widget_features[capability.split(".", 1)[0]]
            if capability in capabilities and feature_enabled(feature):
                module = capability.split(".", 1)[0]
                widgets.append({
                    "capability": capability,
                    "label": label,
                    "value": count(),
                    "url_name": url_name,
                    # Presentation only. Keeping the icon and accent beside the
                    # figure means the card reads as a KPI rather than as a
                    # number on a blank tile, and the template stays free of a
                    # long `{% if %}` ladder over capability names.
                    **WIDGET_STYLE.get(module, DEFAULT_WIDGET_STYLE),
                })

        customer_scope = customers_for(self.request.user)
        lead_scope = leads_for(self.request.user)
        interaction_scope = interactions_for(self.request.user)
        sale_scope = sales_for(self.request.user)
        document_scope = sales_documents_for(self.request.user)
        after_sales_scope = after_sales_requests_for(self.request.user)
        add("customers.scoped", "مشتریان مجاز", customer_scope.count, "common_ui:customers")
        add("customers.company", "مشتریان شرکت", customer_scope.count, "common_ui:customers")
        add("leads.scoped", "صف سرنخ من", lead_scope.count, "common_ui:leads")
        add("leads.company", "سرنخ‌های شرکت", lead_scope.count, "common_ui:leads")
        add("interactions.scoped", "تماس‌های مجاز من", interaction_scope.count, "common_ui:interactions")
        add("interactions.company", "فعالیت مرکز ارتباطات", interaction_scope.count, "common_ui:interactions")
        add("sales.own", "فروش‌های من", sale_scope.count, "common_ui:sales")
        add("sales.company", "فروش‌های شرکت", sale_scope.count, "common_ui:sales")
        add("sales_documents.scoped", "اسناد فروش مجاز", document_scope.count, "common_ui:sales-documents")
        add("sales_documents.company", "رهگیری پستی", document_scope.count, "common_ui:sales-documents")
        add("after_sales.assigned", "پرونده‌های خدمات من", after_sales_scope.count, "common_ui:after-sales")
        add("after_sales.company", "پرونده‌های خدمات پس از فروش", after_sales_scope.count, "common_ui:after-sales")
        if context["can_manage_users"]:
            user_scope = crm_identities(User.objects.all())
            if role == User.Role.SALES_MANAGER:
                user_scope = user_scope.filter(role=User.Role.SALES_AGENT)
            elif role == User.Role.COMPANY_IT:
                user_scope = user_scope.exclude(role=User.Role.PLATFORM_ADMIN)
            widgets.append({
                "capability": next(item for item in capabilities if item.startswith("users.manage_")),
                "label": context["user_admin_label"],
                "value": user_scope.count(),
                "url_name": "common_ui:users",
                **WIDGET_STYLE["users"],
            })
        if context["can_view_audit"]:
            widgets.append({
                "capability": "audit.all" if "audit.all" in capabilities else "audit.non_platform",
                "label": "رویدادهای قابل مشاهده",
                "value": activity_logs_for(self.request.user).count(),
                "url_name": "common_ui:activity-logs",
                **WIDGET_STYLE["audit"],
            })
        context["dashboard_title"], context["dashboard_summary"] = dashboard
        context["dashboard_capability"] = next(item for item in capabilities if item.startswith("dashboard."))
        # Arranged through the same per-user overlay the insight grid below
        # uses, so one editor covers every box on the page and one "back to
        # the default" clears both rows.
        layout = effective_layout(self.request.user)
        context["dashboard_widgets"] = arrange_capability_tiles(widgets, self.request.user, layout=layout)
        # The editor's starting state, rendered into the page so it never
        # depends on the insight request (see `dashboard-layout-state`) —
        # and, since 2.18.4, the width and height steps a border drag snaps
        # between, so the editor no longer asks `/api/v1/dashboard-layout/`
        # for them on every dashboard load.
        context["dashboard_layout_state"] = {
            **layout_state(layout),
            "size_choices": size_choices(),
            "height_choices": height_choices(),
        }
        # Every tile this reader could have, hidden ones included, for the
        # "افزودن ویجت" dialog's real-figure previews.
        context["dashboard_tile_catalog"] = capability_tile_catalog(widgets, layout)
        return context


class UserAdminView(ActiveCrmView):
    def dispatch(self, request, *args, **kwargs):
        if not is_crm_identity(request.user):
            if request.user.is_authenticated or SESSION_KEY in request.session:
                logout(request)
            return redirect("common_ui:login")
        if not has_any_capability(
            request.user,
            "users.manage_agents",
            "users.manage_non_platform",
            "users.manage_all",
        ):
            return self.render_to_response(
                self.get_context_data(
                    error_status=403,
                    error_title="دسترسی مجاز نیست",
                    error_message="شما اجازه مدیریت کاربران را ندارید.",
                ),
                status=403,
            )
        return super().dispatch(request, *args, **kwargs)


class DolphinUserListView(UserAdminView):
    template_name = "common/users/list.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Create User offers exactly the roles `change-role` would also
        # accept from this same admin — one list, so the two screens can
        # never disagree about what is on offer.
        context["assignable_roles"] = assignable_roles(self.request.user)
        return context


class DolphinCustomerListView(ActiveCrmView):
    #: Who besides the Platform Admin may delete from this page (2.18.8).
    delete_capability = "customers.delete"
    required_feature = "customers"
    template_name = "common/customers/list.html"

    def get_context_data(self, **kwargs):
        from sales.selectors import customer_owner_choices

        context = super().get_context_data(**kwargs)
        if context.get("can_assign_customer_owner"):
            context["customer_owner_choices"] = customer_owner_choices()
        return context


class ScopedDetailView(ActiveCrmView):
    object_id_kwarg = "object_id"
    context_id_name = "object_id"
    not_found_title = "مورد پیدا نشد"
    not_found_message = "این مورد در محدوده دسترسی شما وجود ندارد."

    def scoped_queryset(self):
        raise NotImplementedError

    def get(self, request, *args, **kwargs):
        object_id = kwargs[self.object_id_kwarg]
        if not self.scoped_queryset().filter(pk=object_id).exists():
            return self.render_to_response(
                self.get_context_data(
                    error_status=404,
                    error_title=self.not_found_title,
                    error_message=self.not_found_message,
                ),
                status=404,
            )
        return super().get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context[self.context_id_name] = self.kwargs[self.object_id_kwarg]
        return context


class _CampaignPage(ActiveCrmView):
    """Shared by the four campaign pages (2.36.0). Rendering needs only the
    `campaigns` feature; every figure and action behind it is the API's, which
    checks the role capability and the object scope itself."""

    required_feature = "campaigns"

    def get_context_data(self, **kwargs):
        from sales.models import Campaign
        from sales.selectors import customer_owner_choices

        context = super().get_context_data(**kwargs)
        context["can_manage_campaigns"] = "campaigns.manage" in context["capabilities"]
        context["campaign_channels"] = Campaign.Channel.choices
        if context["can_manage_campaigns"]:
            context["customer_owner_choices"] = customer_owner_choices()
        return context


class DolphinCampaignListView(_CampaignPage):
    template_name = "common/campaigns/list.html"


class DolphinCampaignResultsView(_CampaignPage):
    template_name = "common/campaigns/results.html"


class DolphinCampaignAnalyticsView(_CampaignPage):
    template_name = "common/campaigns/analytics.html"


class DolphinCampaignDetailView(ScopedDetailView):
    required_feature = "campaigns"
    template_name = "common/campaigns/detail.html"
    object_id_kwarg = "campaign_id"
    context_id_name = "campaign_id"
    not_found_title = "کمپین پیدا نشد"
    not_found_message = "این کمپین در محدودهٔ دسترسی شما وجود ندارد."

    def scoped_queryset(self):
        from sales.campaign_analytics import campaigns_for

        return campaigns_for(self.request.user)

    def get_context_data(self, **kwargs):
        from sales.selectors import customer_owner_choices

        context = super().get_context_data(**kwargs)
        context["can_manage_campaigns"] = "campaigns.manage" in context["capabilities"]
        if context["can_manage_campaigns"]:
            context["customer_owner_choices"] = customer_owner_choices()
        return context


class DolphinLeadListView(ActiveCrmView):
    #: Who besides the Platform Admin may delete from this page (2.18.8).
    delete_capability = "leads.delete"
    required_feature = "leads"
    template_name = "common/leads/list.html"


class DolphinLeadCalendarView(ActiveCrmView):
    """The same leads, drawn on a month grid by `next_follow_up_at`.

    No extra permission check beyond the feature gate: exactly like
    `DolphinLeadListView`, the page renders for anyone whose deployment runs
    `leads`, and `leads_for`/`leads.scoped`/`leads.company` on the API behind
    it are what actually decide whose leads it can ever draw. A viewer with
    neither capability opens an empty calendar, the same way they would see
    an empty list on the ordinary leads page.
    """

    required_feature = "leads"
    template_name = "common/leads/calendar.html"


class DolphinLeadBoardView(ActiveCrmView):
    """The same leads, grouped into status columns instead of a table.

    Gated by its own `lead_kanban` feature on top of `leads` — unlike
    `DolphinLeadCalendarView` above, which needs no feature of its own. The
    board is a bigger, separately opt-in thing: a new frontend dependency
    (the theme's `jkanban` bundle) and a drag interaction, not a read-only
    reshuffling of a page every `leads` deployment already has. See the
    reasoning beside `lead_kanban` in `common/deployment/registry.py`.

    No extra permission check beyond both feature gates, same as the
    calendar: the page renders for anyone whose deployment runs them, and
    `leads_for`/`leads.scoped`/`leads.company`/`leads.manage` on the API
    behind it are what actually decide whose leads it can ever show or move.
    """

    required_feature = "lead_kanban"
    template_name = "common/leads/board.html"


class DolphinLeadDetailView(ScopedDetailView):
    required_feature = "leads"
    template_name = "common/leads/detail.html"
    object_id_kwarg = "lead_id"
    context_id_name = "lead_id"
    not_found_title = "سرنخ پیدا نشد"
    not_found_message = "سرنخ در محدوده دسترسی شما وجود ندارد."

    def scoped_queryset(self):
        return leads_for(self.request.user)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        lead = self.scoped_queryset().filter(pk=self.kwargs["lead_id"]).only("assigned_to_id").first()
        context["can_edit_lead"] = bool(
            lead
            and (
                self.request.user.role in {
                    User.Role.SALES_MANAGER,
                    User.Role.COMPANY_IT,
                    User.Role.PLATFORM_ADMIN,
                }
                or lead.assigned_to_id == self.request.user.pk
            )
        )
        return context


class DolphinInteractionListView(ActiveCrmView):
    #: Who besides the Platform Admin may delete from this page (2.18.8).
    delete_capability = "interactions.delete"
    required_feature = "leads"
    template_name = "common/interactions/list.html"


class DolphinInteractionDetailView(ScopedDetailView):
    required_feature = "leads"
    template_name = "common/interactions/detail.html"
    object_id_kwarg = "interaction_id"
    context_id_name = "interaction_id"
    not_found_title = "تماس پیدا نشد"
    not_found_message = "تماس در محدوده دسترسی شما وجود ندارد."

    def scoped_queryset(self):
        return interactions_for(self.request.user)


class DolphinProductListView(ActiveCrmView):
    #: Who besides the Platform Admin may delete from this page (2.18.8).
    delete_capability = "products.delete"
    required_feature = "products"
    template_name = "common/products/list.html"


class DolphinProductCategoryListView(ActiveCrmView):
    #: Who besides the Platform Admin may delete from this page (2.18.8).
    delete_capability = "product_categories.delete"
    required_feature = "products"
    template_name = "common/product_categories/list.html"


class DolphinProductCategoryDetailView(ScopedDetailView):
    required_feature = "products"
    template_name = "common/product_categories/detail.html"
    object_id_kwarg = "category_id"
    context_id_name = "category_id"
    not_found_title = "دسته‌بندی پیدا نشد"
    not_found_message = "دسته‌بندی در محدوده دسترسی شما وجود ندارد."

    def scoped_queryset(self):
        return product_categories_for(self.request.user)


class DolphinProductDetailView(ScopedDetailView):
    required_feature = "products"
    template_name = "common/products/detail.html"
    object_id_kwarg = "product_id"
    context_id_name = "product_id"

    def scoped_queryset(self):
        return products_for(self.request.user)


class DolphinSaleListView(ActiveCrmView):
    #: Who besides the Platform Admin may delete from this page (2.18.8).
    records_deletable = False
    required_feature = "sales"
    template_name = "common/sales/list.html"


class DolphinSaleDetailView(ScopedDetailView):
    required_feature = "sales"
    template_name = "common/sales/detail.html"
    object_id_kwarg = "sale_id"
    context_id_name = "sale_id"

    def scoped_queryset(self):
        return sales_for(self.request.user)


class DolphinSalesDocumentListView(ActiveCrmView):
    #: Who besides the Platform Admin may delete from this page (2.18.8).
    delete_capability = "sales_documents.delete"
    required_feature = "sales_documents"
    template_name = "common/sales_documents/list.html"


class DolphinSalesDocumentDetailView(ScopedDetailView):
    required_feature = "sales_documents"
    template_name = "common/sales_documents/detail.html"
    object_id_kwarg = "document_id"
    context_id_name = "document_id"
    not_found_title = "سند فروش پیدا نشد"
    not_found_message = "سند فروش در محدوده دسترسی شما وجود ندارد."

    def scoped_queryset(self):
        return sales_documents_for(self.request.user)


class DolphinUserPerformanceView(ActiveCrmView):
    required_feature = "reports"
    template_name = "common/reports/user_performance.html"

    def dispatch(self, request, *args, **kwargs):
        if is_crm_identity(request.user) and not has_any_capability(request.user, "reports.own", "reports.company"):
            return self.render_to_response(self.get_context_data(
                error_status=403, error_title="دسترسی مجاز نیست",
                error_message="شما اجازه مشاهده این گزارش را ندارید.",
            ), status=403)
        return super().dispatch(request, *args, **kwargs)


class DolphinSalesDocumentReportView(ActiveCrmView):
    required_feature = "sales_documents"
    template_name = "common/reports/sales_documents.html"

    def dispatch(self, request, *args, **kwargs):
        if is_crm_identity(request.user) and not has_any_capability(request.user, "reports.own", "reports.company"):
            return self.render_to_response(self.get_context_data(
                error_status=403, error_title="دسترسی مجاز نیست",
                error_message="شما اجازه مشاهده این گزارش را ندارید.",
            ), status=403)
        return super().dispatch(request, *args, **kwargs)


class DolphinInboundSMSReportView(ActiveCrmView):
    required_feature = "inbound_sms"
    template_name = "common/reports/inbound_sms.html"

    def dispatch(self, request, *args, **kwargs):
        if is_crm_identity(request.user) and not has_any_capability(request.user, "sms.company"):
            return self.render_to_response(self.get_context_data(
                error_status=403, error_title="دسترسی مجاز نیست",
                error_message="شما اجازه مشاهده گزارش پیامک ورودی را ندارید.",
            ), status=403)
        return super().dispatch(request, *args, **kwargs)


class DolphinOutboundSMSView(ActiveCrmView):
    required_feature = "outbound_sms"
    template_name = "common/sms/outbound.html"

    def dispatch(self, request, *args, **kwargs):
        if is_crm_identity(request.user) and not has_any_capability(request.user, "sms.company"):
            return self.render_to_response(self.get_context_data(
                error_status=403, error_title="دسترسی مجاز نیست",
                error_message="شما اجازه ارسال یا مشاهده پیامک را ندارید.",
            ), status=403)
        return super().dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Server-rendered, not fetched by JS: whether the "send" button can
        # possibly work is known before the page even loads, and a Sales
        # Manager without sms-provider-settings access could never call that
        # API to find out for themselves anyway.
        config = sms.resolve_config()
        context["sms_provider_configured"] = config is not None
        context["sms_provider_label"] = config.label if config else ""
        return context


class IntegrationsView(ActiveCrmView):
    """`/settings/integrations/` — every outside service, in one list.

    No feature or role gate of its own, deliberately. What a reader may see
    here is decided row by row by `common.integrations.visible_integrations`,
    against the same gate each service's own settings page enforces, and a
    reader who may configure nothing gets an empty list rather than a 403 —
    "there is nothing here for you" is the true answer, and a permission
    error would suggest there is something being withheld.
    """

    template_name = "common/settings/integrations.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["integrations"] = visible_integrations(self.request.user)
        # The integrations framework (2.21.0): connections, outbound webhooks,
        # API tokens and their log — Platform Admin, feature `integrations`,
        # both checked again by every endpoint behind it.
        context["can_manage_framework"] = (
            feature_enabled("integrations") and self.request.user.role == User.Role.PLATFORM_ADMIN
        )
        if context["can_manage_framework"]:
            from integrations.crypto import secrets_available
            from integrations.events import EVENT_TYPES
            from integrations.providers import providers

            context["integration_secrets_available"] = secrets_available()
            context["integration_catalog"] = {
                "providers": [
                    provider.describe()
                    for provider in providers()
                    if not provider.required_feature or feature_enabled(provider.required_feature)
                ],
                "event_types": [{"key": key, "label": label} for key, label in EVENT_TYPES.items() if key != "webhook.ping"],
            }
            # Whom a token may be bound to: any active CRM account but the
            # Platform Admin (`integrations.services.create_api_token`).
            context["token_users"] = [
                (person.pk, f"{person.get_full_name() or person.username} ({person.username})")
                for person in crm_identities(User.objects.filter(is_active=True))
                .exclude(role=User.Role.PLATFORM_ADMIN)
                .order_by("username")
            ]
            # Whom an extension may be mapped to (2.22.0): any active CRM
            # account (`telephony.services.save_extension`).
            if feature_enabled("telephony"):
                context["telephony_users"] = [
                    (person.pk, f"{person.get_full_name() or person.username} ({person.username})")
                    for person in crm_identities(User.objects.filter(is_active=True)).order_by("username")
                ]
            # One tab per part of the framework this deployment runs (2.24.0),
            # `?tab=` opening one directly; the catalog behind «افزودن اتصال»
            # lists what cannot be connected yet beside what can.
            from common.integrations import UPCOMING_SERVICES

            tabs = [("connections", "اتصال‌ها")]
            if feature_enabled("telephony"):
                tabs.append(("extensions", "داخلی‌های تلفن"))
            if feature_enabled("outbound_webhooks"):
                tabs.append(("webhooks", "وب‌هوک‌های خروجی"))
            if feature_enabled("public_api"):
                tabs.append(("tokens", "توکن‌های API"))
            tabs.append(("logs", "گزارش رویدادها"))
            context["integration_tabs"] = tabs
            requested = self.request.GET.get("tab", "")
            context["active_tab"] = requested if requested in {key for key, _ in tabs} else "connections"
            context["upcoming_services"] = UPCOMING_SERVICES
        return context


class DolphinSmsProviderSettingsView(ActiveCrmView):
    """`/settings/sms-provider/` — this deployment's own outbound SMS gateway.

    Same two-gate shape as `DolphinBrandingSettingsView` right above it:
    feature-gated (`outbound_sms` — a gateway to configure is meaningless
    without the module that would use it), and restricted to a Platform
    Admin on top of that, since it holds real credentials.
    """

    required_feature = "outbound_sms"
    template_name = "common/sms/provider_settings.html"

    def dispatch(self, request, *args, **kwargs):
        if is_crm_identity(request.user) and request.user.role != User.Role.PLATFORM_ADMIN:
            return self.render_to_response(self.get_context_data(
                error_status=403, error_title="دسترسی مجاز نیست",
                error_message="تنظیم سامانهٔ ارسال پیامک فقط برای مدیر پلتفرم مجاز است.",
            ), status=403)
        return super().dispatch(request, *args, **kwargs)


class DolphinPostProviderSettingsView(ActiveCrmView):
    """`/settings/post-provider/` — this deployment's own post-carrier API
    connection (product owner, 2026-09-21: «تنظیمات سامانه پست هم مثل
    پیامک باید صفحه برای تنظیم کردن api داشته باشه»).

    Gated on `sales_documents.manage`, not Platform Admin only — unlike the
    SMS gateway (a platform-wide credential), a post connection is a
    sales-documents concern, the same capability `common/integrations.py`
    already requires to open the post row on «اتصال سرویس‌ها» at all.
    """

    required_feature = "sales_documents"
    template_name = "common/sales_documents/post_provider_settings.html"

    def dispatch(self, request, *args, **kwargs):
        if is_crm_identity(request.user) and not has_any_capability(
            request.user, "sales_documents.manage"
        ):
            return self.render_to_response(self.get_context_data(
                error_status=403, error_title="دسترسی مجاز نیست",
                error_message="تنظیم سامانهٔ پست مجاز نیست.",
            ), status=403)
        return super().dispatch(request, *args, **kwargs)


class AfterSalesAccessView(ActiveCrmView):
    def dispatch(self, request, *args, **kwargs):
        if is_crm_identity(request.user) and not has_any_capability(
            request.user, "after_sales.assigned", "after_sales.company"
        ):
            return self.render_to_response(self.get_context_data(
                error_status=403, error_title="دسترسی مجاز نیست",
                error_message="شما اجازه مشاهده خدمات پس از فروش را ندارید.",
            ), status=403)
        return super().dispatch(request, *args, **kwargs)


class DolphinAfterSalesCalendarView(AfterSalesAccessView):
    """The same after-sales cases, drawn on a month grid by
    `next_appointment_at` — the after-sales mirror of `DolphinLeadCalendarView`.
    """

    required_feature = "after_sales"
    template_name = "common/after_sales/calendar.html"


class DolphinAfterSalesListView(AfterSalesAccessView):
    #: Who besides the Platform Admin may delete from this page (2.18.8).
    delete_capability = "after_sales.delete"
    required_feature = "after_sales"
    template_name = "common/after_sales/list.html"


class DolphinAfterSalesDetailView(AfterSalesAccessView, ScopedDetailView):
    required_feature = "after_sales"
    template_name = "common/after_sales/detail.html"
    object_id_kwarg = "request_id"
    context_id_name = "after_sales_request_id"
    not_found_title = "پرونده پیدا نشد"
    not_found_message = "پرونده در محدوده دسترسی شما وجود ندارد."

    def scoped_queryset(self):
        return after_sales_requests_for(self.request.user)


class AuditReaderView(ActiveCrmView):
    def dispatch(self, request, *args, **kwargs):
        if not is_crm_identity(request.user):
            return super().dispatch(request, *args, **kwargs)
        if not has_any_capability(request.user, "audit.non_platform", "audit.all"):
            return self.render_to_response(
                self.get_context_data(
                    error_status=403,
                    error_title="دسترسی مجاز نیست",
                    error_message="شما اجازه مشاهده رویدادهای سامانه را ندارید.",
                ),
                status=403,
            )
        return super().dispatch(request, *args, **kwargs)


class DolphinActivityLogListView(AuditReaderView):
    required_feature = "audit_log"
    template_name = "common/activity_logs/list.html"


class DolphinActivityLogDetailView(AuditReaderView, ScopedDetailView):
    required_feature = "audit_log"
    template_name = "common/activity_logs/detail.html"
    object_id_kwarg = "activity_log_id"
    context_id_name = "activity_log_id"

    def scoped_queryset(self):
        return activity_logs_for(self.request.user)


# --- Inventory pages ---------------------------------------------------------

class DolphinWarehouseListView(ActiveCrmView):
    #: Who besides the Platform Admin may delete from this page (2.18.8).
    delete_capability = "inventory.delete"
    required_feature = "inventory"
    template_name = "common/warehouses/list.html"


class DolphinWarehouseDetailView(ScopedDetailView):
    required_feature = "inventory"
    template_name = "common/warehouses/detail.html"
    object_id_kwarg = "warehouse_id"
    context_id_name = "warehouse_id"
    not_found_title = "انبار پیدا نشد"
    not_found_message = "انبار در محدوده دسترسی شما وجود ندارد."

    def scoped_queryset(self):
        return warehouses_for(self.request.user)


class DolphinStockLevelListView(ActiveCrmView):
    required_feature = "inventory"
    template_name = "common/inventory/stock_levels.html"


class DolphinStockMovementListView(ActiveCrmView):
    required_feature = "inventory"
    template_name = "common/inventory/stock_movements.html"


# --- Commercial document pages ----------------------------------------------

class DolphinOrderListView(ActiveCrmView):
    #: Who besides the Platform Admin may delete from this page (2.18.8).
    records_deletable = False
    required_feature = "orders"
    template_name = "common/orders/list.html"


class DolphinOrderDetailView(ScopedDetailView):
    required_feature = "orders"
    template_name = "common/orders/detail.html"
    object_id_kwarg = "order_id"
    context_id_name = "order_id"
    not_found_title = "درخواست تأمین پیدا نشد"
    not_found_message = "درخواست تأمین در محدوده دسترسی شما وجود ندارد."

    def scoped_queryset(self):
        return orders_for(self.request.user)


class DolphinOrderBoardView(ActiveCrmView):
    """The same orders, grouped into status columns instead of a table.

    Mirrors `DolphinLeadBoardView` above exactly: gated by its own
    `order_kanban` feature on top of `orders`, a separately opt-in page built
    around the theme's `jkanban` bundle and a drag interaction, not a
    read-only reshuffling of a page every `orders` deployment already has.
    See the reasoning beside `order_kanban` in `common/deployment/registry.py`.

    No extra permission check beyond both feature gates: the page renders
    for anyone whose deployment runs them, and `orders_for`/`orders.scoped`/
    `orders.company` on the API behind it — plus `DOCUMENT_WRITERS` inside
    `billing.services.transition_order` for the actual move — are what
    decide whose orders it can ever show or move.
    """

    required_feature = "order_kanban"
    template_name = "common/orders/board.html"


class DolphinInvoiceListView(ActiveCrmView):
    #: Who besides the Platform Admin may delete from this page (2.18.8).
    records_deletable = False
    required_feature = "invoices"
    template_name = "common/invoices/list.html"


class DolphinInvoiceDetailView(ScopedDetailView):
    required_feature = "invoices"
    template_name = "common/invoices/detail.html"
    object_id_kwarg = "invoice_id"
    context_id_name = "invoice_id"
    not_found_title = "فاکتور پیدا نشد"
    not_found_message = "فاکتور در محدوده دسترسی شما وجود ندارد."

    def scoped_queryset(self):
        return invoices_for(self.request.user)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # The campaign card (2.36.0): shown only where the feature runs and the
        # role may correct attributions; the API re-checks both.
        context["can_attribute_campaigns"] = (
            feature_enabled("campaigns") and "campaigns.attribute" in context["capabilities"]
        )
        # The warehouse fulfilment card (2.37.0): the orders feature, and a role
        # that works orders (the API re-checks scope, status and uniqueness).
        context["can_request_fulfillment"] = feature_enabled("orders") and (
            "orders.manage" in context["capabilities"]
        )
        return context


class PrintableDocumentView(ScopedDetailView):
    """A document rendered for paper: no navigation, no controls, print stylesheet.

    Server-rendered from the stored snapshot rather than assembled by script, so
    what prints is exactly the row. A page that fails to load prints nothing,
    rather than printing a blank form that still looks official.
    """

    def get_document(self):
        raise NotImplementedError

    #: File stem for a downloaded PDF, joined with the document number.
    pdf_name_prefix = "document"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        if not context.get("error_status"):
            document = self.get_document()
            context["document"] = document
            context["items"] = list(document.items.order_by("line_number"))
            context["taxable_amount"] = document.subtotal_amount - document.discount_amount
            # بند ۹.۲ — the amount stated a second time, in words, so a digit
            # cannot be added to it after signing.
            context["total_in_words"] = amount_in_words(document.total_amount)
            context["status_label"] = DOCUMENT_STATUS_LABELS.get(document.status, document.status)
            settlement = getattr(document, "settlement_status", None)
            if settlement is not None:
                context["settlement_label"] = SETTLEMENT_LABELS.get(settlement, settlement)
        # Offer the download only where the server can really produce one.
        context.setdefault("pdf_available", renderer_is_available())
        # The reader's currency unit, restated on the context rather than
        # left to `common.context_processors.panel_preferences` alone.
        # `{{ amount|money:panel_currency_unit }}` is a *filter argument*,
        # and Django raises rather than falling back when one of those does
        # not resolve — so a printed invoice would be a hard error, not a
        # figure in the wrong unit, anywhere this template is rendered
        # outside the request/response cycle. It is a legal document; it
        # does not get to depend on which renderer reached it.
        from common.preferences import currency_label, effective_preferences

        printing_for = effective_preferences(self.request.user)
        context.setdefault("panel_currency_unit", printing_for["currency_unit"])
        context.setdefault("panel_currency_label", currency_label(printing_for["currency_unit"]))
        return context


class DocumentPdfView(PrintableDocumentView):
    """The same print page, printed by the server instead of by the reader.

    Reusing the template rather than building a second layout is the whole
    point: the PDF cannot drift away from the page that was verified in the
    browser, because there is only one of them.
    """

    def get(self, request, *args, **kwargs):
        response = super().get(request, *args, **kwargs)
        status = getattr(response, "status_code", 200)
        if status != 200:
            # Out of scope or feature disabled: answer exactly as the print
            # page does, so a direct URL leaks nothing the page would not.
            return response
        context = response.context_data
        context.update(pdf_mode=True, inline_css=inline_stylesheet())
        html = render_to_string(self.template_name, context, request=request)
        try:
            payload = render_html_to_pdf(html)
        except PdfRendererBusy:
            # Every render slot is taken. Rendering occupies a whole worker, so
            # refusing here is what keeps the rest of the site answering; the
            # browser's own print button still works meanwhile.
            response = self.render_to_response(
                self.get_context_data(
                    error_status=503,
                    error_title="تولید PDF شلوغ است",
                    error_message="در حال حاضر سند دیگری در حال تولید است. چند لحظه بعد دوباره تلاش کنید یا از دکمه «چاپ / ذخیره PDF» مرورگر استفاده کنید.",
                ),
                status=503,
            )
            response["Retry-After"] = "10"
            return response
        except PdfRendererUnavailable:
            return self.render_to_response(
                self.get_context_data(
                    error_status=503,
                    error_title="تولید PDF در دسترس نیست",
                    error_message="این استقرار موتور تولید PDF ندارد. از دکمه «چاپ / ذخیره PDF» مرورگر استفاده کنید.",
                ),
                status=503,
            )
        document = context["document"]
        pdf = HttpResponse(payload, content_type="application/pdf")
        pdf["Content-Disposition"] = f'attachment; filename="{self.pdf_name_prefix}-{document.number}.pdf"'
        return pdf


class DolphinInvoicePrintView(PrintableDocumentView):
    required_feature = "invoices"
    template_name = "common/invoices/print.html"
    object_id_kwarg = "invoice_id"
    context_id_name = "invoice_id"
    not_found_title = "فاکتور پیدا نشد"
    not_found_message = "فاکتور در محدوده دسترسی شما وجود ندارد."

    def scoped_queryset(self):
        return invoices_for(self.request.user)

    def get_document(self):
        return (
            self.scoped_queryset()
            .select_related("customer", "created_by", "warehouse")
            .prefetch_related("items")
            .get(pk=self.kwargs["invoice_id"])
        )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        if context.get("error_status"):
            return context
        document = context["document"]
        items = context["items"]

        # بند ۹ — the sample invoice prints tax on every line. The stored
        # document has one header tax figure, so the columns are derived and
        # forced to add up to it.
        # The footer comes back from the same computation as the columns, so the
        # two cannot drift: they are the same numbers, already in whole rial.
        context["line_rows"], context["line_totals"] = printed_line_breakdown(
            items=items,
            header_discount=document.discount_amount,
            tax_rate=document.tax_rate,
            tax_amount=document.tax_amount,
        )

        # بند ۲ — both parties as they were frozen at issue. An invoice issued
        # before the snapshot existed, or still a draft, has none; it falls back
        # to the live records so the page never prints an empty identity block.
        customer = document.customer
        phone = customer.phones.filter(is_active=True).order_by("-is_primary", "id").first()
        context["buyer"] = {
            "name": document.buyer_name or customer.full_name,
            "national_id": document.buyer_national_id or customer.national_id,
            "economic_code": document.buyer_economic_code or customer.economic_code,
            "address": document.buyer_address or customer.address,
            "postal_code": document.buyer_postal_code or customer.postal_code,
            "city": document.buyer_city or customer.city,
            "phone": document.buyer_phone or (phone.raw_phone if phone else ""),
        }
        context["seller"] = {
            "name": document.seller_name or settings.SELLER_LEGAL_NAME,
            "registration_number": (
                document.seller_registration_number or settings.SELLER_REGISTRATION_NUMBER
            ),
            "national_id": document.seller_national_id or settings.SELLER_NATIONAL_ID,
            "economic_code": document.seller_economic_code or settings.SELLER_ECONOMIC_CODE,
            "address": document.seller_address or settings.SELLER_ADDRESS,
            "postal_code": document.seller_postal_code or settings.SELLER_POSTAL_CODE,
            "city": document.seller_city or settings.SELLER_CITY,
            "phone": document.seller_phone or settings.SELLER_PHONE,
        }
        # A snapshot is what makes the document evidence; say so when there
        # isn't one rather than letting live data pass as frozen.
        context["identity_is_snapshot"] = bool(document.buyer_name)
        return context


class DolphinInvoicePdfView(DocumentPdfView, DolphinInvoicePrintView):
    pdf_name_prefix = "invoice"


# --- Money pages -------------------------------------------------------------

class PaymentDeskView(ActiveCrmView):
    """Pages that handle money: `payments.company` only, never a Sales Agent."""

    def dispatch(self, request, *args, **kwargs):
        if is_crm_identity(request.user) and not has_any_capability(request.user, "payments.company"):
            return self.render_to_response(self.get_context_data(
                error_status=403, error_title="دسترسی مجاز نیست",
                error_message="شما اجازه کار با دریافت‌ها را ندارید.",
            ), status=403)
        return super().dispatch(request, *args, **kwargs)


class DolphinPaymentListView(PaymentDeskView):
    """Money coming in.

    Receipts and disbursements are the same document read in two directions, so
    they share one template and one page handler. What differs is the wording —
    a receipt names a customer, a disbursement names whoever was paid — and that
    is carried in the context rather than duplicated into a second copy of two
    hundred lines of markup that would then drift.
    """

    required_feature = "payments"
    template_name = "common/payments/list.html"
    direction = "receipt"
    #: Who besides the Platform Admin may delete from this page (2.18.8).
    records_deletable = False

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["payment_direction"] = self.direction
        return context


class DolphinDisbursementListView(DolphinPaymentListView):
    """Money going out. The same desk, facing the other way."""

    direction = "disbursement"


class DolphinPaymentDetailView(PaymentDeskView, ScopedDetailView):
    required_feature = "payments"
    template_name = "common/payments/detail.html"
    #: Whether this reader may correct a recorded document. The platform admin
    #: may; everyone else sees the same page read-only. Checked here as well as
    #: in the API — the field being editable on screen is a convenience, never
    #: the authorisation.
    
    object_id_kwarg = "payment_id"
    context_id_name = "payment_id"
    not_found_title = "دریافت پیدا نشد"
    not_found_message = "دریافت در محدوده دسترسی شما وجود ندارد."

    def scoped_queryset(self):
        return payments_for(self.request.user)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["can_edit_payment"] = (
            self.request.user.role == User.Role.PLATFORM_ADMIN
        )
        # Which desk this document belongs to, resolved here rather than left to
        # the script. The page is titled and the sidebar is lit before any
        # request completes, so a disbursement opened from «پرداخت‌ها» must not
        # spend its first paint calling itself a receipt and lighting the
        # «دریافت‌ها» entry — which is what it did, because both desks share this
        # one route and the nav matches by URL prefix.
        context["payment_direction"] = (
            self.scoped_queryset()
            .filter(pk=self.kwargs[self.object_id_kwarg])
            .values_list("direction", flat=True)
            .first()
        )
        return context


class DolphinChequeListView(PaymentDeskView):
    required_feature = "cheques"
    template_name = "common/payments/cheques.html"


class DolphinInstallmentListView(PaymentDeskView):
    required_feature = "payments"
    template_name = "common/payments/installments.html"


class DolphinCustomerLedgerView(ActiveCrmView):
    required_feature = "customer_ledger"
    template_name = "common/reports/customer_ledger.html"

    def dispatch(self, request, *args, **kwargs):
        if is_crm_identity(request.user) and not has_any_capability(
            request.user, "ledger.company", "ledger.own"
        ):
            return self.render_to_response(self.get_context_data(
                error_status=403, error_title="دسترسی مجاز نیست",
                error_message="شما اجازه مشاهده دفتر حساب مشتری را ندارید.",
            ), status=403)
        return super().dispatch(request, *args, **kwargs)


# --- Financial report pages --------------------------------------------------

class CompanyReportView(ActiveCrmView):
    """Money reports need `reports.company`; `reports.own` is not enough."""

    def dispatch(self, request, *args, **kwargs):
        if is_crm_identity(request.user) and not has_any_capability(request.user, "reports.company"):
            return self.render_to_response(self.get_context_data(
                error_status=403, error_title="دسترسی مجاز نیست",
                error_message="شما اجازه مشاهده این گزارش را ندارید.",
            ), status=403)
        return super().dispatch(request, *args, **kwargs)


class DolphinReceivablesReportView(CompanyReportView):
    required_feature = "invoices"
    template_name = "common/reports/receivables.html"


class DolphinProfitReportView(CompanyReportView):
    required_feature = "invoices"
    template_name = "common/reports/profit.html"


class DolphinStockValuationReportView(CompanyReportView):
    required_feature = "inventory"
    template_name = "common/reports/stock_valuation.html"


class DolphinBrandingSettingsView(ActiveCrmView):
    """`/branding/` — this deployment's own choice of name/logo.

    Feature-gated (`required_feature`, inherited dispatch: 404 when this
    deployment's manifest never turned `custom_branding` on — the page looks
    exactly like one that was never built, same as every other disabled
    module) and, on top of that, restricted to a Platform Admin — the same
    dispatch-override-then-403 shape `DolphinCustomerLedgerView` and
    `CompanyReportView` already use, so a lower role sees a plain "access
    denied" card, not a login redirect or a stack trace.
    """

    required_feature = "custom_branding"
    template_name = "common/branding/settings.html"

    def dispatch(self, request, *args, **kwargs):
        if is_crm_identity(request.user) and request.user.role != User.Role.PLATFORM_ADMIN:
            return self.render_to_response(self.get_context_data(
                error_status=403, error_title="دسترسی مجاز نیست",
                error_message="تغییر نام و لوگوی پنل فقط برای مدیر پلتفرم مجاز است.",
            ), status=403)
        return super().dispatch(request, *args, **kwargs)


#: `DolphinDashboardLayoutSettingsView` (`/settings/dashboard/`) was retired
#: in 2.8.0 at the product owner's request: "صفحهٔ چیدمان داشبورد را
#: حذف کن و خود داشبورد را قابل شخصی‌سازی کن". A deployment-wide layout
#: nobody could reach from the screen it described has been replaced by an
#: in-place editor on the dashboard itself, per user — see
#: `common/dashboard_layout.py` for how the deployment default and a
#: reader's own overlay combine, and `DashboardLayoutView` for the endpoint
#: the editor saves through. The deployment row and its data are untouched.


from common.backup_views import RESTORE_CONFIRMATION as BACKUP_RESTORE_CONFIRMATION


class DolphinSettingsView(ActiveCrmView):
    """`/settings/` — one page for everything a person can change about
    how this panel behaves for them, plus the deployment-wide sections
    whoever is allowed to change those already had elsewhere.

    Not feature-gated. Every user, on every deployment, has a typeface, a
    scale, a currency unit and a colour theme; there is no deployment for
    which "this customer did not license font size" is a sensible sentence.
    The admin-only sections inside it carry their own gates, exactly the
    ones their own pages carried, and each is rendered only when both that
    feature and that role say yes — `can_manage_branding` and friends,
    computed once in `ActiveCrmView.get_context_data`.
    """

    template_name = "common/settings/settings.html"

    def get_context_data(self, **kwargs):
        from common import backups, preferences

        context = super().get_context_data(**kwargs)
        current = preferences.effective_preferences(self.request.user)
        context["preference_catalog"] = preferences.catalog()
        context["current_preferences"] = current
        # Both gates, the same shape as `can_manage_branding`: the feature
        # *and* the role, checked again by the endpoint regardless of what
        # this rendered. `backups.available()` folds in a third question
        # neither of those answers — whether the volume is actually
        # mounted — because a section offering downloads from a directory
        # that is not there would be a control that only looks real.
        context["can_manage_backups"] = (
            self.request.user.role == User.Role.PLATFORM_ADMIN and backups.available()
        )
        context["restore_confirmation"] = BACKUP_RESTORE_CONFIRMATION
        # How much each factor of the person score counts (2.20.0): Platform
        # Admin, and only where scoring runs. `scoring-settings/` checks both
        # again.
        context["can_manage_scoring"] = (
            feature_enabled("person_scoring") and self.request.user.role == User.Role.PLATFORM_ADMIN
        )
        if context["can_manage_scoring"]:
            from scoring.views import catalog

            context["scoring_catalog"] = catalog()
        # One tab per group that has anything to show this reader. A tab's
        # content is rendered whether or not it is the active one (the page
        # switches without a reload); `?tab=` makes any tab linkable.
        tabs = [("display", "نمایش پنل")]
        if context["can_manage_scoring"]:
            tabs.append(("scoring", "امتیازدهی"))
        if context["can_manage_backups"]:
            tabs.append(("backups", "پشتیبان‌گیری"))
        if context["can_manage_branding"] or context["can_manage_integrations"]:
            tabs.append(("deployment", "استقرار"))
        requested = self.request.GET.get("tab", "")
        context["settings_tabs"] = tabs
        context["active_tab"] = requested if requested in {key for key, _ in tabs} else "display"
        return context


class DolphinChatView(ActiveCrmView):
    """`/chat/` — internal chat as a full page (product-owner decision,
    2026-09-28, reversing 1.9.0's removal below).

    `DolphinChatView` was retired in 1.9.0 in favour of a header-icon-
    triggered drawer, on the reasoning that a full page beside the drawer
    would be "a second, divergent chat UI, not a fallback for it". That risk
    is real but not inherent to having a page — it is what happens if the
    page runs its own copy of the engine. This page does not: its script
    (`setupChatPage`, `common/static/common/js/`) is the drawer's
    own `setupChat` given a different set of element ids and left open
    permanently instead of toggled by `data-dolphin-drawer`, so both read and
    write through the exact same `chat/` API, the same `sessionStorage`
    cache key and the same unread/read semantics — one engine, two
    presentations, not two chat UIs. The drawer stays for a quick reply from
    anywhere; this page is the fuller workspace the sidebar links to when
    someone means to sit and read a conversation.

    Feature availability and role permission are unchanged from the drawer:
    gated on `internal_chat`, open to every ordinary role, no further
    capability check — the same as the header icon that opens the drawer.
    """

    required_feature = "internal_chat"
    template_name = "common/chat.html"
