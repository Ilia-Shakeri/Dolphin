"""What the home page shows each role, beyond a row of bare counts.

Product-owner request (2026-09-04): the dashboard was the weakest surface in
the panel relative to everything around it — four tiles carrying a count, one
performance panel, and (for a marketer) a work queue. Every other page had
charts, filters and real figures; the first page anyone sees had the least.

This module answers three questions per role, and the answers differ by
role because the questions do:

* **KPIs** — a figure with a *comparison*, not a bare count. "۳۷٬۰۰۰٬۰۰۰
  ریال this month" says little; "…, ۱۲٪ more than last month" says what a
  reader actually wanted to know.
* **Trend** — sales over the last twelve weeks, so direction is visible
  without opening a report.
* **Breakdown** — where the work is sitting: leads by status for the sales
  side, after-sales cases by status for the after-sales side.

The same three shapes as `reminders`, `search` and `customer_timeline`, for
the same reasons: no new table, nothing stored, object scope taken from each
module's own selector, and only feature availability checked here. A role
that cannot see sales simply has no sales KPI and no trend — the panel is
assembled from what that reader may see, never filtered afterwards.
"""

from datetime import timedelta
from decimal import Decimal

from django.db.models import Count, Sum
from django.utils import timezone

from accounts.models import User
from aftersales.selectors import after_sales_requests_for
from billing.selectors import invoices_for
from common import formatting
from common.dashboard_layout import apply_layout
from common.dashboard_panels import panels_for
from common.preferences import effective_preferences
from common.deployment.profile import feature_enabled
from sales.models import Lead, Sale
from sales.selectors import interactions_for, leads_for, sales_for

#: Weeks on the trend chart. A quarter is long enough to show a direction and
#: short enough that the most recent weeks are still legible.
TREND_WEEKS = 12

#: Slices before the breakdown stops being readable.
BREAKDOWN_LIMIT = 6

#: How many of the trend's own trailing points a KPI tile's sparkline shows.
#: A sparkline reads as "the recent shape", not the full twelve-week story the
#: chart below it already tells — six is enough to see a direction in a strip
#: a few centimetres wide.
SPARK_WEEKS = 6

#: Sellers named on the "share of this month" gauge before the rest are
#: folded into an "دیگران" ring — same reasoning as `TOP_CITIES` above: a
#: ring per seller stops being readable past a handful, and a company with
#: more than that still has one honest, whole answer to "who sold how much".
TOP_SELLERS = 5


def _kpi(
    key, label, *, display, hint="", icon="di-element-11", icon_paths=4, accent="primary", url=None,
    spark=None, direction=None, full_display="",
):
    return {
        "key": key,
        "label": label,
        "display": display,
        # The exact figure when `display` is a shortened amount, for the tile's
        # tooltip; blank when `display` already is the whole figure.
        "full_display": full_display if full_display != display else "",
        "hint": hint,
        # "up"/"down" when `hint` states a month/week-over-month comparison,
        # else None — lets the tile show a direction arrow instead of asking
        # the reader to parse "بیشتر"/"کمتر" out of a sentence to tell
        # whether a change was good or bad (product-owner design review,
        # 2026-09-12).
        "direction": direction,
        "icon": icon,
        "icon_paths": icon_paths,
        "accent": accent,
        "url": url,
        # A short recent series (product-owner request 2026-09-11: the tile
        # should carry its own shape, not just a number and a one-line
        # comparison). `None` where drawing one would cost a query this KPI
        # has no other reason to run — the tile simply shows no spark, the
        # same "absent, not fabricated" rule every other optional part of
        # this panel already follows.
        "spark": spark,
    }


def _month_bounds(now):
    """This month so far, and the same span of the month before it.

    Compared against the *same number of days* into the previous month, not
    the whole of it: on the 3rd, "this month vs last month" would otherwise
    read as a collapse every single time.
    """
    local = timezone.localtime(now)
    start = local.replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=local.day - 1)
    elapsed = now - start
    previous_start = (start - timedelta(days=1)).replace(day=1)
    return start, previous_start, previous_start + elapsed


def _change_hint(current, previous, *, noun):
    """«۱۲٪ بیشتر از ماه گذشته», or a plain statement when there is no base."""
    if previous and previous > 0:
        percent = int(round((current - previous) / previous * 100))
        if percent == 0:
            return f"مثل {noun} گذشته"
        direction = "بیشتر" if percent > 0 else "کمتر"
        return f"{formatting.persian_digits(abs(percent))}٪ {direction} از {noun} گذشته"
    if current:
        return f"در {noun} گذشته چیزی ثبت نشده بود"
    return f"در این {noun} چیزی ثبت نشده"


def _change_direction(current, previous):
    """"up"/"down" for exactly the comparison `_change_hint` puts into words,
    None when that hint has no base to compare against (or states no change).
    """
    if previous and previous > 0 and current != previous:
        return "up" if current > previous else "down"
    return None


def _sales_kpis(user, *, now, unit, trend=None):
    scope = sales_for(user).exclude(status=Sale.Status.CANCELLED)
    start, previous_start, previous_end = _month_bounds(now)
    this_month = scope.filter(sold_at__gte=start)
    last_month = scope.filter(sold_at__gte=previous_start, sold_at__lt=previous_end)
    amount = this_month.aggregate(total=Sum("total_amount"))["total"] or Decimal("0")
    previous = last_month.aggregate(total=Sum("total_amount"))["total"] or Decimal("0")
    count = this_month.count()
    # The tile's own spark rides on the trend this same call already computed
    # (`dashboard_for` builds it first) rather than a second query — the last
    # SPARK_WEEKS points of the same twelve-week series, oldest first, same
    # as the trend chart itself reads.
    amount_spark = [point["value"] for point in trend["points"][-SPARK_WEEKS:]] if trend else None
    count_spark = list(trend["counts"][-SPARK_WEEKS:]) if trend else None
    return [
        _kpi(
            "sales_amount_this_month", "فروش این ماه",
            display=formatting.money_compact(amount, unit),
            full_display=formatting.money(amount, unit),
            hint=_change_hint(amount, previous, noun="ماه"),
            direction=_change_direction(amount, previous),
            icon="di-chart-line-up", icon_paths=2, accent="success", url="/sales/",
            spark=amount_spark,
        ),
        _kpi(
            "sales_count_this_month", "تعداد فروش این ماه",
            display=formatting.persian_digits(count),
            hint=_change_hint(count, last_month.count(), noun="ماه"),
            direction=_change_direction(count, last_month.count()),
            icon="di-basket", icon_paths=4, accent="primary", url="/sales/",
            spark=count_spark,
        ),
    ]


def _receivables_kpi(user, *, now, unit):
    """What is still owed, across every issued invoice this reader may see.

    Summed in Python rather than in SQL because `balance_due` is a property
    that honours `is_manually_settled` — a manually settled invoice owes
    nothing even though its stored columns still show a figure. A `Sum()`
    over the columns would quietly disagree with every other page.
    """
    invoices = invoices_for(user).filter(status="issued")
    outstanding = sum((invoice.balance_due for invoice in invoices), Decimal("0"))
    unpaid = sum(1 for invoice in invoices if invoice.balance_due > 0)
    return [
        _kpi(
            "outstanding", "مطالبات باز",
            display=formatting.money_compact(outstanding, unit),
            full_display=formatting.money(outstanding, unit),
            hint=f"{formatting.persian_digits(unpaid)} فاکتور تسویه‌نشده",
            icon="di-wallet", icon_paths=4, accent="warning", url="/reports/receivables/",
        )
    ]


def _call_kpi(user, *, now):
    week_start = timezone.localtime(now) - timedelta(days=7)
    previous_start = week_start - timedelta(days=7)
    scope = interactions_for(user)
    this_week = scope.filter(occurred_at__gte=week_start).count()
    last_week = scope.filter(occurred_at__gte=previous_start, occurred_at__lt=week_start).count()

    # This tile's own spark: SPARK_WEEKS buckets ending today, bucketed in
    # Python over one ordered query — the same reasoning `_sales_trend`
    # documents (PostgreSQL/SQLite disagree on week-truncation functions, and
    # a handful of buckets over one indexed range scan is not worth a
    # dialect-specific query).
    spark_start = week_start - timedelta(weeks=SPARK_WEEKS - 1)
    rows = scope.filter(occurred_at__gte=spark_start).values_list("occurred_at", flat=True)
    buckets = [0] * SPARK_WEEKS
    for occurred_at in rows:
        index = (timezone.localtime(occurred_at) - spark_start).days // 7
        if 0 <= index < SPARK_WEEKS:
            buckets[index] += 1

    return [
        _kpi(
            "calls_this_week", "تماس‌های هفت روز اخیر",
            display=formatting.persian_digits(this_week),
            hint=_change_hint(this_week, last_week, noun="هفته"),
            direction=_change_direction(this_week, last_week),
            icon="di-call", icon_paths=8, accent="info", url="/interactions/",
            spark=buckets,
        )
    ]


def _after_sales_kpis(user, *, now):
    scope = after_sales_requests_for(user)
    open_cases = scope.filter(closed_at__isnull=True)
    start, _previous_start, _previous_end = _month_bounds(now)
    return [
        _kpi(
            "after_sales_open", "پرونده‌های باز",
            display=formatting.persian_digits(open_cases.count()),
            hint=(
                f"{formatting.persian_digits(open_cases.filter(next_appointment_at__isnull=False).count())}"
                " مورد با قرار ثبت‌شده"
            ),
            icon="di-wrench", icon_paths=2, accent="danger", url="/after-sales/",
        ),
        _kpi(
            "after_sales_closed_this_month", "بسته‌شده در این ماه",
            display=formatting.persian_digits(scope.filter(closed_at__gte=start).count()),
            hint="از ابتدای ماه جاری",
            icon="di-check-circle", icon_paths=2, accent="success", url="/after-sales/",
        ),
    ]


def _gauge(key, label, *, rate, hint, accent="primary", url=None):
    """A 0–100 figure meant for the radial gauge, not a bare KPI tile.

    `rate` is already a plain float in that range — every caller below
    computes it from a real denominator it has just checked is non-zero, so
    there is no NaN/None case to guard here.
    """
    return {
        "key": key,
        "label": label,
        "value": round(rate, 1),
        "display": f"{formatting.persian_digits(round(rate))}٪",
        "hint": hint,
        "accent": accent,
        "url": url,
    }


def _gauges(user, *, now, unit):
    """Three real ratios, each already derivable from a module's own scoped
    data — no stored target, no invented business rule. A sales quota or
    per-agent target is a genuine product decision (who sets the number, per
    agent or per team, renewed how often) that nothing in this codebase has
    answered yet, so this deliberately does not fabricate one.
    """
    gauges = []

    if feature_enabled("leads"):
        leads = leads_for(user)
        decided = leads.filter(status__in=[Lead.Status.COMPLETED, Lead.Status.CANCELLED]).count()
        if decided:
            completed = leads.filter(status=Lead.Status.COMPLETED).count()
            rate = completed / decided * 100
            gauges.append(
                _gauge(
                    "lead_conversion_rate", "نرخ تبدیل سرنخ",
                    rate=rate,
                    hint=f"{formatting.persian_digits(completed)} از {formatting.persian_digits(decided)} سرنخ تصمیم‌گیری‌شده",
                    accent="success", url="/leads/",
                )
            )

    if feature_enabled("invoices"):
        invoices = list(invoices_for(user).filter(status="issued"))
        if invoices:
            total = sum((invoice.total_amount for invoice in invoices), Decimal("0"))
            outstanding = sum((invoice.balance_due for invoice in invoices), Decimal("0"))
            if total > 0:
                collected = total - outstanding
                rate = float(collected / total) * 100
                gauges.append(
                    _gauge(
                        "receivables_collection_rate", "نرخ وصول مطالبات",
                        rate=rate,
                        hint=f"{formatting.money(collected, unit)} از {formatting.money(total, unit)} وصول شده",
                        accent="info", url="/reports/receivables/",
                    )
                )

    if feature_enabled("after_sales"):
        cases = after_sales_requests_for(user)
        total_cases = cases.count()
        if total_cases:
            closed = cases.filter(closed_at__isnull=False).count()
            rate = closed / total_cases * 100
            gauges.append(
                _gauge(
                    "after_sales_closure_rate", "نرخ بسته‌شدن پرونده‌ها",
                    rate=rate,
                    hint=f"{formatting.persian_digits(closed)} از {formatting.persian_digits(total_cases)} پرونده بسته‌شده",
                    accent="warning", url="/after-sales/",
                )
            )

    return gauges


def _sales_trend(user, *, now, unit):
    """Sales amount *and* count per week for the last twelve weeks, oldest
    first — amount is what the chart draws as its area, count is what it
    draws as the overlaid bar (product-owner request 2026-09-11: a mixed
    chart reads how much *and* how many at once, which a bare amount line
    never told the reader).

    Bucketed in Python over one ordered query rather than with a database
    date-truncation function: this codebase runs on PostgreSQL in production
    and SQLite in development and tests, and the two disagree about week
    boundaries. Twelve buckets over one indexed range scan is not worth a
    dialect-specific query.
    """
    local_now = timezone.localtime(now)
    start_of_today = local_now.replace(hour=0, minute=0, second=0, microsecond=0)
    first_bucket_start = start_of_today - timedelta(weeks=TREND_WEEKS - 1, days=local_now.weekday())
    rows = (
        sales_for(user)
        .exclude(status=Sale.Status.CANCELLED)
        .filter(sold_at__gte=first_bucket_start)
        .values_list("sold_at", "total_amount")
    )
    amount_buckets = [Decimal("0")] * TREND_WEEKS
    count_buckets = [0] * TREND_WEEKS
    for sold_at, amount in rows:
        index = (timezone.localtime(sold_at) - first_bucket_start).days // 7
        if 0 <= index < TREND_WEEKS:
            amount_buckets[index] += amount or Decimal("0")
            count_buckets[index] += 1
    points = []
    for index, amount in enumerate(amount_buckets):
        week_start = first_bucket_start + timedelta(weeks=index)
        points.append({
            "label": _jalali_day(week_start),
            "value": float(amount),
            "display": formatting.money(amount, unit),
        })
    total = sum(amount_buckets, Decimal("0"))
    return {
        "title": "روند فروش دوازده هفتهٔ اخیر",
        "points": points,
        "counts": count_buckets,
        "summary": f"مجموع این بازه: {formatting.money(total, unit)}",
    }


def _jalali_day(value):
    from common.jalali import format_date

    return format_date(value)


def _lead_breakdown(user):
    rows = (
        leads_for(user)
        .values("status")
        .annotate(total=Count("id"))
        .order_by("-total")[:BREAKDOWN_LIMIT]
    )
    labels = dict(Lead.Status.choices)
    items = [
        {
            "label": labels.get(row["status"], row["status"] or "بدون وضعیت"),
            "value": row["total"],
            "display": formatting.persian_digits(row["total"]),
        }
        for row in rows
    ]
    return {"title": "سرنخ‌ها به تفکیک وضعیت", "items": items, "url": "/leads/"}


def _after_sales_breakdown(user):
    rows = (
        after_sales_requests_for(user)
        .values("status")
        .annotate(total=Count("id"))
        .order_by("-total")[:BREAKDOWN_LIMIT]
    )
    items = [
        {
            "label": row["status"] or "بدون وضعیت",
            "value": row["total"],
            "display": formatting.persian_digits(row["total"]),
        }
        for row in rows
    ]
    return {"title": "پرونده‌ها به تفکیک وضعیت", "items": items, "url": "/after-sales/"}


def _agent_share(user, *, now, unit):
    """Each seller's share of this month's confirmed sales amount, as a
    multi-ring gauge (product-owner request 2026-09-11).

    Built from `sales_for(user)`'s own scope — a lone sales agent's scope
    is only their own sales, so this returns `None` for them rather than a
    single 100% ring that names nothing a table couldn't say in one line;
    the shape is only worth drawing once there are at least two sellers to
    compare, which in practice means a manager, IT, or platform-admin view.
    """
    start, _previous_start, _previous_end = _month_bounds(now)
    rows = list(
        sales_for(user)
        .exclude(status=Sale.Status.CANCELLED)
        .filter(sold_at__gte=start)
        .values("sold_by_id", "sold_by__username", "sold_by__first_name", "sold_by__last_name")
        .annotate(total=Sum("total_amount"))
        .order_by("-total")
    )
    if len(rows) < 2:
        return None

    total_amount = sum((row["total"] or Decimal("0")) for row in rows) or Decimal("1")
    top = rows[:TOP_SELLERS]
    rest = rows[TOP_SELLERS:]

    def seller_name(row):
        full = f"{row['sold_by__first_name']} {row['sold_by__last_name']}".strip()
        return full or row["sold_by__username"]

    items = [
        {
            "label": seller_name(row),
            "value": round(float((row["total"] or Decimal("0")) / total_amount) * 100, 1),
            "amount_display": formatting.money(row["total"] or Decimal("0"), unit),
        }
        for row in top
    ]
    if rest:
        rest_amount = sum((row["total"] or Decimal("0")) for row in rest)
        items.append({
            "label": f"{formatting.persian_digits(len(rest))} بازاریاب دیگر",
            "value": round(float(rest_amount / total_amount) * 100, 1),
            "amount_display": formatting.money(rest_amount, unit),
        })

    return {
        "title": "سهم هر بازاریاب از فروش این ماه",
        "items": items,
        "total_display": formatting.money(total_amount, unit),
        "url": "/reports/user-performance/",
    }


def dashboard_for(user, *, now=None):
    """The role's own panel: KPIs, a trend, and a breakdown.

    Every part is optional. A reader who may see none of the sources gets
    empty lists and `None`s rather than an error, and the page simply does
    not render those sections — the same way a withheld feature leaves no
    trace anywhere else in the panel.
    """
    now = now or timezone.now()
    # Rial or toman, this reader's own choice (`common.preferences`). Passed
    # down rather than looked up inside each helper: every figure on one
    # dashboard belongs to one reader, and one lookup per request beats one
    # per KPI.
    unit = effective_preferences(user)["currency_unit"]
    after_sales_side = (
        user.role == User.Role.SALES_AGENT and user.workstream == User.Workstream.AFTER_SALES
    )

    # Computed before the KPIs, not after: the sales KPIs' own sparklines
    # (2026-09-11) ride on this same twelve-week query rather than running a
    # second one for a six-point strip.
    trend = None
    if feature_enabled("sales") and sales_for(user).exists():
        trend = _sales_trend(user, now=now, unit=unit)

    kpis = []
    if feature_enabled("sales") and sales_for(user).exists():
        kpis.extend(_sales_kpis(user, now=now, unit=unit, trend=trend))
    if feature_enabled("invoices") and invoices_for(user).exists():
        kpis.extend(_receivables_kpi(user, now=now, unit=unit))
    if feature_enabled("leads") and interactions_for(user).exists():
        kpis.extend(_call_kpi(user, now=now))
    if feature_enabled("after_sales") and after_sales_requests_for(user).exists():
        kpis.extend(_after_sales_kpis(user, now=now))

    breakdown = None
    if after_sales_side:
        if feature_enabled("after_sales") and after_sales_requests_for(user).exists():
            breakdown = _after_sales_breakdown(user)
    elif feature_enabled("leads") and leads_for(user).exists():
        breakdown = _lead_breakdown(user)

    gauges = _gauges(user, now=now, unit=unit)

    agent_share = None
    if feature_enabled("sales") and sales_for(user).exists():
        agent_share = _agent_share(user, now=now, unit=unit)

    # This deployment's default arrangement with this reader's own overlay
    # on top, applied last — after every KPI/trend/breakdown/gauge/share
    # above has already been scoped to what this specific reader may see.
    # See `common.dashboard_layout`.
    return apply_layout({
        "kpis": kpis, "trend": trend, "breakdown": breakdown, "gauges": gauges, "agent_share": agent_share,
        "panels": panels_for(user, now=now),
    }, user)
