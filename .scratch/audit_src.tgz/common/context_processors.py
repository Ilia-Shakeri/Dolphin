"""Values every rendered page needs, regardless of which view produced it."""

from django.conf import settings

#: The cookie `DolphinToggle` writes when the sidebar is collapsed. The name is
#: `data-dolphin-` plus the toggle's `data-dolphin-toggle-name`, and it is the vendor's
#: own contract — their markup expects the server to read it back and stamp the
#: attribute on `<body>` before the page paints.
SIDEBAR_MINIMIZE_COOKIE = "data-dolphin-app-sidebar-minimize"


def sidebar_state(request):
    """Whether the sidebar should render collapsed.

    Read on the server rather than restored by script on load. This panel does
    full page loads between screens, so a collapsed sidebar would otherwise
    paint open and then snap shut on every single navigation — the flicker is
    the whole reason the theme designed it this way.
    """
    return {
        "sidebar_minimized": request.COOKIES.get(SIDEBAR_MINIMIZE_COOKIE) == "on",
    }


def product_version(request):
    """The running version, for the footer.

    A context processor rather than a base-view mixin because the footer lives
    in `base.html` and every template extends it — including the login page and
    the error pages, which are rendered by views that share no base class.
    """
    return {"dolphin_version": settings.DOLPHIN_VERSION}


def brand(request):
    """The name/logo every template should render — same reasoning as
    `product_version` above: the login page and the error pages need this
    too, and neither shares a base view class with the rest of the panel.

    `common.branding.effective_brand` already folds the `custom_branding`
    feature gate in, so this stays a thin pass-through rather than a second
    place that decision could drift from the one in `common/branding.py`.
    """
    from common.branding import effective_brand
    from common.color import accent_theme_css

    result = effective_brand()
    return {
        "brand_name": result["name"],
        "brand_subtitle": result["subtitle"],
        "brand_is_custom": result["is_custom"],
        "brand_logo_updated_at": result["logo_updated_at"],
        # Pre-rendered CSS text, not just the raw colour — `base.html` only
        # has to decide whether to emit a `<style>` tag, never how to build
        # one; see `common.color.accent_theme_css` for the actual derivation.
        "brand_accent_css": accent_theme_css(result["accent_color"]),
    }


def panel_preferences(request):
    """One reader's own typeface, scale, currency unit and colour theme.

    Same reasoning as `brand` above for why this is a context processor and
    not a base-view mixin: the login page and the error pages need it too
    (they render in the panel's shell and would otherwise jump to a
    different typeface), and neither shares a base class with the rest of
    the panel. `common.preferences.effective_preferences` already answers
    "anonymous visitor" and "database briefly unreachable" with the
    defaults, so this stays a thin pass-through.

    `panel_currency_unit` is exported as well as pre-rendered CSS because
    two other consumers need the raw value: `money_tags.money` in the
    printed documents, and the `data-currency-unit` attribute `base.html`
    puts on `<body>` for the panel script to read.
    """
    from common.preferences import currency_label, effective_preferences, needs_font_sheet, preference_css

    result = effective_preferences(getattr(request, "user", None))
    return {
        "panel_preference_css": preference_css(result),
        "panel_font_family": result["font_family"],
        "panel_font_sheet": needs_font_sheet(result),
        "panel_font_scale": result["font_scale"],
        "panel_currency_unit": result["currency_unit"],
        "panel_currency_label": currency_label(result["currency_unit"]),
        "panel_theme": result["theme"],
    }
