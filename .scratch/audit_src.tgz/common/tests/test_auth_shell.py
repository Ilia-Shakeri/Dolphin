from common.tests.panel_js import PANEL_SCRIPT
import json
import re
from pathlib import Path

from django.core.cache import cache
from django.test import Client, SimpleTestCase, TestCase, override_settings

from accounts.models import User
from accounts.access import ROLE_CAPABILITIES
from common.ui_views import ROLE_LABELS


ROOT = Path(__file__).resolve().parents[2]


def _is_theme_font_token(value):
    """Whether a `font-family` value is nothing but a `--bs-*` custom property."""
    return bool(re.fullmatch(r"var\(\s*--bs-[a-z0-9-]+\s*\)", value.strip()))


class AuthShellUnitTests(SimpleTestCase):
    def test_role_labels_cover_exact_fixed_roles(self):
        self.assertEqual(set(ROLE_LABELS), {value for value, _ in User.Role.choices})
        self.assertEqual(len(ROLE_LABELS), 4)

    def test_client_has_persian_error_states_and_same_origin_requests(self):
        script = (PANEL_SCRIPT).read_text(encoding="utf-8")

        for status in (403, 404, 409, 429):
            self.assertIn(f'{status}: "', script)
        self.assertIn('credentials: "same-origin"', script)
        self.assertIn('headers["X-CSRFToken"]', script)
        self.assertIn('class ApiError', script)
        # No static `.html` target in the *code*. Checked with comments
        # stripped: the panel talks to `/api/` and navigates by route, and the
        # blanket check this replaces also caught prose — three comments that
        # merely cite `base.html`, `leads/list.html` and a reference demo page
        # by name, which is exactly the kind of reference a comment should be
        # free to make (2026-09-20).
        code = re.sub(r"/\*.*?\*/", "", script, flags=re.S)
        code = re.sub("//[^" + chr(10) + "]*", "", code)
        self.assertNotIn(".html", code)

    def test_the_shell_comes_from_the_theme_not_from_a_second_design_system(self):
        """Layout is the purchased theme's job; the override sheet must not redo it.

        The responsive shell, sidebar and mobile drawer are the theme's own
        (`app-sidebar`, `data-dolphin-drawer`), so the rules that used to build a
        bespoke grid here are gone on purpose. What is left is only behaviour
        the theme does not cover, the brand mark, and the print sheet — and this
        test fails if a parallel design system starts growing back.
        """
        shell = (ROOT / "common" / "templates" / "common" / "base.html").read_text(encoding="utf-8")

        # The theme provides the shell.
        self.assertIn('class="app-sidebar flex-column"', shell)
        self.assertIn('data-dolphin-drawer="true"', shell)
        self.assertIn('data-dolphin-drawer-toggle="#nav-toggle"', shell)
        self.assertIn("common/ui/css/dolphin-theme.rtl.css", shell)
        self.assertIn("common/ui/js/dolphin-theme.js", shell)

        # The override sheet stays small and must not restate the theme.
        #
        # Measured in declarations rather than lines. A line count was the first
        # proxy and it was the wrong one: this file is deliberately more than
        # half comment, because every rule here exists to work around something
        # and the reason is worth more than the rule. Counting lines charged the
        # sheet for its own explanations and would have been satisfied by
        # deleting them, which is the opposite of what this test wants.
        #
        # Declarations measure the thing actually at issue — how much CSS is
        # here. A second design system is hundreds; the repairs, the brand mark
        # and the print sheet together are under a hundred.
        # The declaration count that used to be asserted here is gone, and this
        # is the note it left behind.
        #
        # It moved 120 -> 140 -> 160 -> 180 across four releases, every time for
        # a defensible reason: glue for a sidebar that collapses to a rail,
        # native select popups, a filter grid, a searchable combobox the theme
        # can only supply via a 3.5 MB bundle this deployment does not load, a
        # theme popup, and hover labels for a 75px rail of icons. None of it was
        # a second `.btn`.
        #
        # A ceiling that only ever rises is measuring the panel's growth, not
        # its discipline — and each raise cost a review argument that produced
        # no finding. The rule worth keeping is the one below, which names the
        # thing actually forbidden and does not need a number to do it.

    def test_the_override_sheet_does_not_rebuild_the_themes_components(self):
        """The rule the number above is a proxy for, asserted directly.

        The ceiling has now moved three releases running — 120, 140, 160, 180 —
        and each time for a defensible reason: glue for the collapsing sidebar,
        a filter grid, a searchable combobox, a theme popup. None of them is a
        second `.btn`, which is what this file actually cares about.

        That it keeps moving says the count is the wrong instrument, not that
        the rule is wrong. **Before raising it a fifth time, replace it**: this
        test is the one worth keeping, and a number that only ever goes up
        measures the project's growth rather than its discipline.
        """
        stylesheet = (ROOT / "common" / "static" / "common" / "dolphin.css").read_text(encoding="utf-8")
        self.assertNotIn("grid-template-columns: 17rem", stylesheet)
        # A *bare* component selector is what is forbidden — a rule that owns
        # `.btn`, `.card` or `.table` outright. A descendant rule like
        # `.row-actions .btn` or `.jalali-picker .jalali-picker-header .btn`
        # is the opposite: it positions one detail inside one context, which
        # the paragraph above explicitly allows ("may position a detail; may
        # not own any of these").
        #
        # The substring check this replaces could not tell the two apart, so
        # it read `.row-actions .btn {` as a redefinition of the theme's
        # button and had been failing since before 2.7.0 for a rule nobody
        # objected to. Anchored to the start of a line, which in this sheet is
        # where a selector always begins.
        for component in (".btn", ".card", ".table"):
            with self.subTest(component=component):
                self.assertIsNone(
                    re.search(rf"^{re.escape(component)}\s*[,{{]", stylesheet, re.M),
                    f"{component} is redefined outright; scope it to a context instead",
                )
        # Layout and palette belong to the purchased bundle. The sheet may
        # position a detail; it may not own any of these.
        for owned_by_theme in ("--bs-primary:", "@font-face"):
            self.assertNotIn(owned_by_theme, stylesheet, owned_by_theme)
        # Typeface was in that list until 1.3.12, as a flat ban. It is narrowed
        # rather than dropped: the sheet still may not choose a typeface for the
        # panel, but it must be able to undo one place where the vendor chose
        # wrongly for it. The theme's own Apex stylesheet forces `Inter` with
        # `!important` on chart text, and Inter has no Persian glyphs — so every
        # axis label in this Persian panel fell through to an OS substitute.
        #
        # The narrow form: any `font-family` here has to sit on the theme's own
        # `.apexcharts-*` text nodes. Anything else is the sheet owning the type
        # again, which is what the ban was for.
        # `font-family: inherit` is exempt, and is the opposite of the thing
        # banned: it names no typeface at all, it hands the decision back to
        # whatever the theme already set on the ancestor. A bare `<input>`
        # does not inherit type by default — browsers give form controls their
        # own font — so undoing that is the only way a control the theme does
        # not style can match the panel around it (the board column search,
        # 2026-09-20).
        for rule in stylesheet.split("}"):
            if "font-family:" not in rule:
                continue
            selector = rule.split("{")[0]
            declared = [
                line.split("font-family:", 1)[1].strip().rstrip(";").strip()
                for line in rule.splitlines() if "font-family:" in line
            ]
            # `inherit` and a bare theme token are both exempt, and for the
            # same reason: neither names a typeface. `inherit` hands the
            # decision to the ancestor; `var(--bs-font-monospace)` hands it
            # to the theme's own token, which is the thing this ban exists
            # to keep in charge. Naming a family — «IRANSansWeb», «Inter» —
            # is what is banned, and still is.
            if declared and all(
                value == "inherit" or _is_theme_font_token(value) for value in declared
            ):
                continue
            self.assertIn("apexcharts", selector, selector.strip())
        # It keeps exactly the three things it is for.
        self.assertIn("[hidden]", stylesheet)
        self.assertIn("dialog {", stylesheet)
        self.assertIn("@media print", stylesheet)

    def test_a_denied_page_runs_no_page_module(self):
        """The denial card replaces the page's markup, so its module must not run.

        It used to run anyway and throw an uncaught TypeError behind the Persian
        "not permitted" card — invisible to the user, but a real error on a
        served page. Navigation and sign-out still have to work there, so the
        guard sits after them.
        """
        script = (PANEL_SCRIPT).read_text(encoding="utf-8")
        guard = 'if (document.getElementById("app-error")) return;'
        self.assertIn(guard, script)
        before, _, after = script.partition(guard)
        for always_wired in ("setupNav();", "setupLogout();"):
            self.assertIn(always_wired, before, always_wired)
        self.assertIn('const page = document.body.dataset.page;', after)

    def test_the_print_sheet_fits_a_phone(self):
        """The print page loads no theme bundle, so it owns its own containment.

        Each of these was a real overflow: the page box ignored its padding, the
        seven-column line-item table pushed the document sideways, and the
        totals column cut an eight-digit rial amount off at the edge of the
        sheet. On paper the table must go back to visible — a clipped line item
        is a missing line item.
        """
        stylesheet = (ROOT / "common" / "static" / "common" / "dolphin.css").read_text(encoding="utf-8")
        self.assertIn(".print-page { box-sizing: border-box;", stylesheet)
        self.assertIn(".print-page .table-wrap { overflow-x: auto; }", stylesheet)
        self.assertIn(".print-page .table-wrap { overflow-x: visible; }", stylesheet)
        self.assertIn("width: min(100%, 26rem)", stylesheet)
        self.assertIn("grid-template-columns: minmax(0, 12rem) minmax(0, 1fr)", stylesheet)


class AuthShellBrowserTests(TestCase):
    def setUp(self):
        self.password = "Strong-pass-937!"
        self.platform = User.objects.create_user(
            username="platform.shell",
            password=self.password,
            role=User.Role.PLATFORM_ADMIN,
        )
        self.company_it = User.objects.create_user(
            username="it.shell",
            password=self.password,
            role=User.Role.COMPANY_IT,
        )
        self.manager = User.objects.create_user(
            username="manager.shell",
            password=self.password,
            role=User.Role.SALES_MANAGER,
        )
        self.agent = User.objects.create_user(
            username="agent.shell",
            password=self.password,
            role=User.Role.SALES_AGENT,
        )

    def test_public_login_is_persian_rtl_and_has_no_dead_auth_controls(self):
        response = self.client.get("/login/")
        content = response.content.decode("utf-8")

        self.assertEqual(response.status_code, 200)
        self.assertIn('<html lang="fa" dir="rtl">', content)
        self.assertIn("ورود به سامانه", content)
        self.assertIn('action="/api/v1/auth/login/"', content)
        self.assertIn('name="username"', content)
        self.assertIn('name="password"', content)
        self.assertIn('/static/common/brand/Logo-With-Name.webp', content)
        self.assertIn('/static/common/brand/Logo-With-Name.png', content)
        self.assertNotIn('action="#"', content)
        self.assertNotIn("ثبت نام", content)
        self.assertNotIn("sign-up", content)

    def test_protected_routes_redirect_anonymous_and_inactive_users(self):
        self.assertRedirects(self.client.get("/"), "/login/")
        self.client.force_login(self.agent)
        self.agent.is_active = False
        self.agent.save(update_fields=["is_active"])

        response = self.client.get("/")

        self.assertRedirects(response, "/login/")
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_desktop_user_shell_only_shows_real_routes(self):
        self.client.force_login(self.platform)

        response = self.client.get("/users/")
        content = response.content.decode("utf-8")

        self.assertEqual(response.status_code, 200)
        self.assertIn('name="viewport"', content)
        self.assertIn('id="app-sidebar"', content)
        self.assertIn('href="/"', content)
        self.assertIn('href="/users/"', content)
        self.assertIn('action="/api/v1/users/"', content)
        self.assertNotIn('action="#"', content)
        self.assertNotIn("roles/list.html", content)
        self.assertNotIn("ثبت نام", content)

    def test_role_aware_landing_and_navigation_match_backend_capabilities(self):
        expected = {
            User.Role.PLATFORM_ADMIN: ("پنل مدیر پلتفرم", {"users", "audit", "customers", "leads", "interactions", "sales", "products", "performance"}),
            User.Role.SALES_MANAGER: ("پنل مدیر فروشگاه", {"customers", "leads", "interactions", "sales", "products", "performance"}),
            User.Role.SALES_AGENT: ("میز کار بازاریاب", {"customers", "leads", "interactions", "sales", "products", "performance"}),
        }
        for role, (title, modules) in expected.items():
            actor = {
                User.Role.PLATFORM_ADMIN: self.platform,
                User.Role.SALES_MANAGER: self.manager,
                User.Role.SALES_AGENT: self.agent,
            }[role]
            self.client.force_login(actor)
            content = self.client.get("/").content.decode("utf-8")
            with self.subTest(role=role):
                self.assertIn(title, content)
                self.assertIn(f'data-dashboard-capability="dashboard.{"platform" if role == User.Role.PLATFORM_ADMIN else "store" if role == User.Role.SALES_MANAGER else "agent"}"', content)
                for module in modules:
                    self.assertIn(f'data-module="{module}"', content)
                self.assertNotIn('href="#"', content)
                self.assertNotIn('data-future-module=', content)
                if role == User.Role.PLATFORM_ADMIN:
                    self.assertIn('data-platform-navigation="true"', content)
                else:
                    self.assertNotIn('data-platform-navigation="true"', content)
                if role != User.Role.PLATFORM_ADMIN:
                    self.assertNotIn('data-module="users"', content)
                if role == User.Role.SALES_AGENT:
                    self.assertNotIn('data-module="audit"', content)
                    self.assertIn("محصولات (فقط خواندنی)", content)
                    self.assertIn('id="agent-work-queue"', content)
                    self.assertIn("پیگیری بعدی", content)
                    self.assertIn('data-performance-panel="dashboard"', content)
                    self.assertNotIn('id="dashboard-user"', content)
                else:
                    self.assertNotIn('id="agent-work-queue"', content)
                    self.assertIn('data-performance-panel="dashboard"', content)
                    self.assertIn('id="dashboard-user"', content)

    def test_mobile_shell_has_accessible_navigation_control(self):
        self.client.force_login(self.platform)

        response = self.client.get("/")

        self.assertContains(response, 'id="nav-toggle"')
        self.assertContains(response, 'aria-controls="app-sidebar"')
        self.assertContains(response, 'aria-expanded="false"')
        self.assertContains(response, 'brand-mark-mobile')

    def test_home_renders_authoritative_label_for_each_fixed_role(self):
        role_labels = {
            User.Role.SALES_AGENT: "بازاریاب (کال سنتر)",
            User.Role.SALES_MANAGER: "مدیر فروشگاه",
            User.Role.COMPANY_IT: "مدیر فنی مشتری",
            User.Role.PLATFORM_ADMIN: "مدیر پلتفرم",
        }

        for role, label in role_labels.items():
            with self.subTest(role=role):
                user = User.objects.create_user(
                    username=f"role-label-{role}",
                    password=self.password,
                    role=role,
                )
                self.client.force_login(user)
                self.assertContains(self.client.get("/"), label)
                self.client.logout()

    def test_only_platform_admin_can_open_user_management(self):
        # User administration is platform_admin only, so both the Sales Agent
        # and the Sales Manager are denied the pages and the navigation entry.
        for user in (self.agent, self.manager):
            self.client.force_login(user)
            with self.subTest(role=user.role):
                home = self.client.get("/")
                denied_list = self.client.get("/users/")
                # `/users/<id>/` is the person profile since 2.19.0: it opens
                # for the agent (their own) and the manager (the performance
                # report's scope), but no account administration is on it.
                profile = self.client.get(f"/users/{self.agent.pk}/")

                self.assertEqual(home.status_code, 200)
                self.assertNotContains(home, "مدیریت کاربران")
                self.assertNotContains(home, "مدیریت بازاریابان")
                self.assertNotContains(home, 'href="/users/"')
                self.assertEqual(denied_list.status_code, 403)
                self.assertContains(denied_list, "اجازه مدیریت کاربران را ندارید", status_code=403)
                self.assertEqual(profile.status_code, 200)
                for marker in ('id="edit-username"', 'id="change-role-form"', 'id="toggle-user-active"'):
                    self.assertNotContains(profile, marker)

        self.client.force_login(self.platform)
        platform_list = self.client.get("/users/")
        platform_agent = self.client.get(f"/users/{self.agent.pk}/")
        self.assertEqual(platform_list.status_code, 200)
        self.assertContains(platform_list, "مدیریت کاربران")
        self.assertEqual(platform_agent.status_code, 200)
        self.assertContains(platform_agent, 'id="change-role-form"')

    def test_company_it_has_no_user_administration_pages(self):
        # Company IT holds no user-administration capability, so every user
        # page is denied before any target is resolved.
        self.client.force_login(self.company_it)

        home = self.client.get("/")
        platform_detail = self.client.get(f"/users/{self.platform.pk}/")
        agent_detail = self.client.get(f"/users/{self.agent.pk}/")

        self.assertEqual(home.status_code, 200)
        self.assertNotContains(home, 'href="/users/"')
        self.assertEqual(self.client.get("/users/").status_code, 403)
        # Company IT reads everyone's performance (`reports.company`), so both
        # profiles open since 2.19.0 — and neither carries any account
        # administration.
        for detail in (platform_detail, agent_detail):
            self.assertEqual(detail.status_code, 200)
            for marker in ('id="edit-username"', 'id="change-role-form"', 'id="toggle-user-active"'):
                self.assertNotContains(detail, marker)

    def test_platform_admin_sees_exact_controlled_role_options(self):
        self.client.force_login(self.platform)

        content = self.client.get(f"/users/{self.agent.pk}/").content.decode("utf-8")

        for role in ("sales_agent", "sales_manager", "company_it"):
            self.assertEqual(content.count(f'<option value="{role}">'), 1)
        # `platform_admin` is never an option, not even for a Platform Admin
        # actor — exactly one Platform Admin exists at a time, provisioned
        # only by `bootstrap_platform_admin`.
        self.assertNotIn('<option value="platform_admin">', content)
        # The per-user permission matrix is reachable from the profile's
        # «دسترسی‌ها» tab since 2.19.0 — as the one dialog User Management
        # also uses, never as a second copy.
        self.assertEqual(content.count('id="permissions-dialog"'), 1)

    @override_settings(DEBUG=False)
    def test_unknown_route_has_safe_persian_404(self):
        response = self.client.get("/route-that-does-not-exist/")

        self.assertEqual(response.status_code, 404)
        self.assertContains(response, "صفحه پیدا نشد", status_code=404)
        self.assertContains(response, "Dolphin | دلفین", status_code=404)

    def test_the_error_shell_loads_the_theme_its_classes_come_from(self):
        """`error.html` used `card` and `btn btn-primary` without ever loading
        the stylesheet those classes come from — the "card" had no border or
        shadow and the link home rendered as bare underlined text. Pinned the
        same way `ChartLibraryTests` pins the load order in base.html."""
        content = self.client.get("/route-that-does-not-exist/").content.decode("utf-8")

        self.assertIn('/static/common/ui/css/dolphin-plugins.rtl.css', content)
        self.assertIn('/static/common/ui/css/dolphin-theme.rtl.css', content)
        self.assertLess(
            content.index("dolphin-plugins.rtl.css"),
            content.index("dolphin-theme.rtl.css"),
        )


class AuthShellApiFlowTests(TestCase):
    def setUp(self):
        # Throttle buckets are keyed by user id, and a rolled-back test hands
        # the next one the same ids — so a class that makes many requests can
        # inherit the previous class's spend and get 429 where it expected 201.
        # Every other request-heavy class in this suite clears it the same way.
        cache.clear()
        self.password = "Strong-pass-937!"
        self.platform = User.objects.create_user(
            username="platform.api.shell",
            password=self.password,
            role=User.Role.PLATFORM_ADMIN,
        )
        self.client = Client(enforce_csrf_checks=True)

    def _json(self, method, path, payload=None):
        csrf_token = self.client.cookies["csrftoken"].value
        return getattr(self.client, method)(
            path,
            data=json.dumps(payload) if payload is not None else None,
            content_type="application/json",
            HTTP_X_CSRFTOKEN=csrf_token,
        )

    def test_same_origin_session_flow_covers_auth_and_user_lifecycle(self):
        login_page = self.client.get("/login/")
        self.assertEqual(login_page.status_code, 200)
        self.assertIn("csrftoken", self.client.cookies)

        login = self._json("post", "/api/v1/auth/login/", {"username": self.platform.username, "password": self.password})
        self.assertEqual(login.status_code, 200)
        self.assertIn("sessionid", self.client.cookies)
        self.assertEqual(self.client.get("/api/v1/auth/me/").status_code, 200)

        created = self._json(
            "post",
            "/api/v1/users/",
            {
                "username": "made.by.shell",
                "password": "Another-strong-731!",
                "role": User.Role.SALES_AGENT,
                "first_name": "کاربر",
                "last_name": "آزمایشی",
                "email": "shell@example.test",
                "phone": "02100000000",
            },
        )
        self.assertEqual(created.status_code, 201, created.content)
        created_data = created.json()
        self.assertEqual(created_data["role"], User.Role.SALES_AGENT)

        user_path = f'/api/v1/users/{created_data["id"]}/'
        self.assertEqual(self.client.get("/api/v1/users/").status_code, 200)
        self.assertEqual(self.client.get(user_path).status_code, 200)
        edited = self._json("patch", user_path, {"first_name": "ویرایش"})
        self.assertEqual(edited.status_code, 200)
        changed = self._json("post", f'{user_path}change-role/', {"role": User.Role.SALES_MANAGER})
        self.assertEqual(changed.status_code, 200)
        self.assertEqual(changed.json()["role"], User.Role.SALES_MANAGER)
        deactivated = self._json("patch", user_path, {"is_active": False})
        self.assertEqual(deactivated.status_code, 200)
        self.assertFalse(deactivated.json()["is_active"])
        self.assertEqual(self._json("post", "/api/v1/auth/logout/").status_code, 204)
        self.assertEqual(self.client.get("/api/v1/auth/me/").status_code, 403)

    def test_shell_offers_role_at_creation_but_never_in_the_edit_form(self):
        # Role selection moved from server-controlled to a required Create
        # User input (the whole point of the permission-matrix feature), but
        # it still never appears on the *edit* form — a role change only ever
        # happens through the dedicated, audited `change-role` flow.
        self.client.force_login(self.platform)

        listing = self.client.get("/users/").content.decode("utf-8")
        detail = self.client.get(f"/users/{self.platform.pk}/").content.decode("utf-8")

        create_form = listing.split('id="create-user-form"', 1)[1].split("</form>", 1)[0]
        edit_form = detail.split('id="edit-user-form"', 1)[1].split("</form>", 1)[0]
        self.assertIn('name="role"', create_form)
        self.assertNotIn('name="is_active"', create_form)
        self.assertNotIn('name="role"', edit_form)
        self.assertNotIn('name="is_active"', edit_form)

    def test_me_returns_backend_authorized_capabilities(self):
        self.client.force_login(self.platform)
        response = self.client.get("/api/v1/auth/me/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["capabilities"], sorted(ROLE_CAPABILITIES[User.Role.PLATFORM_ADMIN]))
