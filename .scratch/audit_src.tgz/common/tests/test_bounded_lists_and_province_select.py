"""Three unrelated fixes from the same design review (2026-09-12), each
pinned by source pattern since none needs a browser or a database:

* the lead/order kanban columns show roughly five cards before scrolling
  internally, raised from four;
* the performance panel's own "جزئیات همان محدوده مجاز" table (shared by the
  dashboard and the standalone عملکرد report) is capped and scrollable the
  same way, so a company-wide scope with many users no longer pushes
  everything below it down the page;
* a customer's province is chosen from the same fixed list the choropleth
  map itself reads, not typed free-text — a typo or variant spelling used to
  mean a customer's own province never matched a region on the map, silently.
"""

from common.tests.panel_js import PANEL_SCRIPT
import pathlib

from django.test import SimpleTestCase

REPOSITORY_ROOT = pathlib.Path(__file__).resolve().parents[2]
CSS = (REPOSITORY_ROOT / "common" / "static" / "common" / "dolphin.css").read_text(encoding="utf-8")
SCRIPT = (
    PANEL_SCRIPT
).read_text(encoding="utf-8")
TEMPLATES = REPOSITORY_ROOT / "common" / "templates" / "common"
PROFILE_TABS = REPOSITORY_ROOT / "profiles" / "templates" / "profiles" / "tabs"


def _function_body(name):
    start = SCRIPT.index(f"function {name}(")
    end = SCRIPT.index("\n    function ", start + 1)
    return SCRIPT[start:end]


def _css_rule(selector):
    start = CSS.index(selector)
    return CSS[start:CSS.index("}", start)]


class KanbanColumnHeightTests(SimpleTestCase):
    def test_a_column_shows_four_whole_cards_and_part_of_the_next(self):
        """Restated for 2.7.0, which replaced the flat `37.5rem` this used
        to assert with a height derived from one measured card.

        The rule the product owner asked for twice is the same both times —
        a column must show several cards without the board growing — but the
        2.7.0 ask added the part that matters: «حداقل ۴ کارت و ذره‌ای از
        کارت بعدی». A column cut flush after the fourth reads as one that
        holds exactly four, and nobody scrolls a list that appears to have
        ended. So this asserts the shape of the rule rather than a literal;
        `test_board_cards_and_search.ColumnHeightTests` pins the multiplier.
        """
        rule = _css_rule("#lead-board .kanban-drag,\n#order-board .kanban-drag {")
        self.assertIn("--dolphin-board-card:", rule)
        self.assertRegex(rule, r"max-height:\s*calc\(var\(--dolphin-board-card\) \* 4\.\d+\)")
        # The two flat heights this rule carried before; neither may return
        # without the reasoning above being revisited.
        self.assertNotIn("max-height: 30rem;", rule)
        self.assertNotIn("max-height: 37.5rem;", rule)

    def test_the_column_still_scrolls_internally_rather_than_growing_the_page(self):
        """Restated 2026-09-20: the same 0.35rem gap, now expressed as a
        physical `padding-right`. `.dolphin-hover-scroll` flips this element
        to `direction: ltr` so the scrollbar sits on the right of an RTL
        column, and the logical property would follow that flip and put the
        gap on the left, away from the bar it exists to clear."""
        rule = _css_rule("#lead-board .kanban-drag,\n#order-board .kanban-drag {")
        self.assertIn("padding-right: 0.35rem;", rule)


class PerformanceScopeTableTests(SimpleTestCase):
    def test_the_scope_table_carries_the_bounded_scroll_class(self):
        content = (TEMPLATES / "includes" / "performance_panel.inc").read_text(encoding="utf-8")
        self.assertIn('class="table-responsive performance-scope-table-wrap hover-scroll-overlay-y"', content)

    def test_the_bounded_class_actually_caps_and_scrolls(self):
        rule = _css_rule(".performance-scope-table-wrap {")
        self.assertIn("max-height:", rule)
        self.assertIn("overflow-y: auto;", rule)


class ProvinceSelectTests(SimpleTestCase):
    """A typo-proof dropdown, not a second hand-typed list — see
    `fillProvinceSelect`'s own docstring in the panel script."""

    def test_fill_province_select_reads_the_same_source_the_map_uses(self):
        body = _function_body("fillProvinceSelect")
        self.assertIn("await loadIranMap()", body)
        self.assertIn("province.name", body)

    def test_an_unmatched_existing_value_is_kept_not_dropped(self):
        """Opening the edit form must never silently rewrite a customer's
        own stored record just because it predates this dropdown."""
        body = _function_body("fillProvinceSelect")
        self.assertIn("!names.includes(selectedValue)", body)
        self.assertIn("select.value = selectedValue", body)

    def test_both_customer_forms_use_a_select_not_free_text(self):
        # The edit form moved into the customer profile's «اطلاعات» tab in
        # 2.19.0 (`profiles/templates/profiles/tabs/customer_info.inc`).
        for relative_path, field_id in (
            (TEMPLATES / "customers/list.html", "create-customer-province"),
            (PROFILE_TABS / "customer_info.inc", "edit-customer-province"),
        ):
            content = relative_path.read_text(encoding="utf-8")
            with self.subTest(template=relative_path):
                self.assertIn(f'<select class="form-select form-select-solid" id="{field_id}"', content)
                self.assertNotIn(f'<input class="form-control form-control-solid" id="{field_id}"', content)

    def test_both_forms_are_actually_wired_to_fill_the_select(self):
        self.assertIn(
            'fillProvinceSelect(document.getElementById("create-customer-province"))', SCRIPT
        )
        self.assertIn(
            'fillProvinceSelect(document.getElementById("edit-customer-province"), value.province || "")',
            SCRIPT,
        )
